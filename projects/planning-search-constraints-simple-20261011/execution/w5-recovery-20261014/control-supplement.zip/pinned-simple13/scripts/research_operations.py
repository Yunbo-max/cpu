#!/usr/bin/env python3
"""Opt-in local recovery tools. No background service, remote sync, or cleanup.

Same-host reservations coordinate only participants using this exact lock domain.
Content-addressed snapshots copy explicit files, not whole project histories.
"""
from __future__ import annotations
from contextlib import contextmanager
import argparse
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import tempfile
import time
import uuid


def _safe_relative(name):
    if not isinstance(name,str) or not name or '\\' in name or '\x00' in name or PurePosixPath(name).is_absolute() or any(x in {'','..','.'} for x in name.split('/')):
        raise ValueError('explicit safe project-relative path required')
    return name


def _directory(path):
    p=Path(path).absolute()
    for ancestor in [p,*p.parents]:
        if ancestor.is_symlink():raise ValueError('symlink directory is not an ownership boundary')
    p.mkdir(parents=True,exist_ok=True)
    return p


def _json_bytes(value):return (json.dumps(value,sort_keys=True,allow_nan=False,separators=(',',':'))+'\n').encode()


def _kv(text):
    out={}
    for line in text.splitlines():
        k,v=line.split();out[k]=int(v)
    return out


def memory_snapshot(cgroup='/sys/fs/cgroup'):
    """Read one explicitly resolved cgroup; ancestor data is collected when visible."""
    p=Path(cgroup).resolve(strict=True);errors=[]
    def read(name,parse):
        try:return parse((p/name).read_text())
        except (OSError,ValueError) as e:errors.append({'file':name,'error':str(e)});return None
    def bound(s):return None if s.strip()=='max' else int(s)
    current=read('memory.current',int);maximum=read('memory.max',bound)
    pressure=read('memory.pressure',lambda s:{line.split()[0]:{k:float(v) for k,v in (x.split('=') for x in line.split()[1:])} for line in s.splitlines() if line.strip()})
    try:boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    except OSError:boot='unknown-boot'
    identity=p.stat();domain=hashlib.sha256(f'{boot}:{identity.st_dev}:{identity.st_ino}:{p}'.encode()).hexdigest()
    ancestor=[]
    for a in p.parents:
        if not (a/'memory.current').is_file():break
        try:
            lim=bound((a/'memory.max').read_text());used=int((a/'memory.current').read_text())
            if lim is not None:ancestor.append(max(0,lim-used))
        except (OSError,ValueError) as e:errors.append({'file':str(a),'error':str(e)})
    return dict(domain=domain,cgroup=str(p),boot_id=boot,observed_at=time.time(),
                memory_current=current,memory_max=maximum,ancestor_headrooms=ancestor,
                memory_stat=read('memory.stat',_kv),memory_events=read('memory.events',_kv),memory_pressure=pressure,
                errors=errors,snapshot_is_lease=False,notes='file includes shmem; do not add them or count file cache as free. Resolve the actual cgroup/mount before use.')


def memory_advice(snapshot, *, peak_bytes, margin_bytes, already_accounted_bytes=0,pending_reservations=0):
    for value in (peak_bytes,margin_bytes,already_accounted_bytes,pending_reservations):
        if type(value)is not int or value<0:raise ValueError('nonnegative integer byte observations required')
    if already_accounted_bytes>peak_bytes:raise ValueError('already-accounted footprint exceeds measured peak')
    need=peak_bytes-already_accounted_bytes+margin_bytes
    report=dict(status='unknown_capacity',needed_additional_bytes=need,cache_credit_bytes=0,reservation=False,
                warning='Measured need is an estimate, not an OOM guarantee. Unknown/uncooperating consumers are not controlled.')
    used,lim=snapshot.get('memory_current'),snapshot.get('memory_max')
    if type(used)is not int or type(lim)is not int or used<0 or lim<0:return report
    ancestors=snapshot.get('ancestor_headrooms',[])
    if not isinstance(ancestors,list) or any(type(v)is not int or v<0 for v in ancestors):return report
    available=max(0,min([lim-used,*ancestors])-pending_reservations)
    status='task_exceeds_observed_limit' if peak_bytes+margin_bytes>lim else 'fits_observed_headroom' if need<=available else 'waiting_for_memory'
    report.update(status=status,available_unreserved_bytes=available,deficit_bytes=max(0,need-available))
    return report


@contextmanager
def _locked(path):
    p=_directory(path);fd=os.open(p/'coordination.lock',os.O_CREAT|os.O_RDWR|os.O_NOFOLLOW,0o600)
    try:
        fcntl.flock(fd,fcntl.LOCK_EX);yield p
    finally:fcntl.flock(fd,fcntl.LOCK_UN);os.close(fd)


def _read_json(path, default=None):
    if not path.exists():return default
    if path.is_symlink() or path.stat().st_size>8*1024*1024:raise ValueError('invalid bounded state')
    return json.loads(path.read_text())


def _atomic_json(path,value):
    fd,name=tempfile.mkstemp(prefix='.own-write-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as f:f.write(_json_bytes(value));f.flush();os.fsync(f.fileno())
        os.replace(name,path)
        d=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(d)
        finally:os.close(d)
    finally:
        if os.path.exists(name):os.unlink(name)


def reserve(directory,snapshot_fn,project_id,task_id,peak_bytes,margin_bytes):
    """Fresh observation and cooperative reservation under one filesystem lock.

    No automatic expiry: unknown processes retain reservations until reconciled.
    Full reservations plus cgroup current may conservatively double-count running
    jobs; this protocol prioritizes avoiding optimistic unaccounted allocation.
    """
    if not all(isinstance(x,str) and x for x in (project_id,task_id)):raise ValueError('project/task identity required')
    with _locked(directory) as p:
        snapshot=snapshot_fn()
        stamp=snapshot.get('observed_at')
        if type(stamp)not in {int,float} or not math.isfinite(stamp) or not 0<=time.time()-stamp<=5:
            raise ValueError('a fresh observation must be made inside the admission lock')
        domain=snapshot.get('domain')
        if not isinstance(domain,str) or not domain:raise ValueError('verified host/cgroup domain required')
        state=_read_json(p/'reservations.json',{'domain':domain,'reservations':{}})
        if state['domain']!=domain:raise ValueError('different host/cgroup coordination domain; reconcile explicitly')
        if any(x['project_id']==project_id and x['task_id']==task_id for x in state['reservations'].values()):
            raise ValueError('task already reserved; reconcile instead of duplicating')
        pending=sum(x['reserved_bytes'] for x in state['reservations'].values())
        report=memory_advice(snapshot,peak_bytes=peak_bytes,margin_bytes=margin_bytes,pending_reservations=pending)
        if report['status']!='fits_observed_headroom':return report
        token=uuid.uuid4().hex
        state['reservations'][token]=dict(project_id=project_id,task_id=task_id,reserved_bytes=report['needed_additional_bytes'],created_at=time.time())
        _atomic_json(p/'reservations.json',state)
        return dict(report,status='reserved',reservation=True,token=token,domain=domain)


def release(directory,token,domain):
    """Call only after reconciling this owned task as terminal; no process killing."""
    with _locked(directory) as p:
        state=_read_json(p/'reservations.json')
        if not state or state['domain']!=domain or token not in state['reservations']:raise ValueError('unknown lease/domain')
        del state['reservations'][token];_atomic_json(p/'reservations.json',state)
        return dict(status='released',token=token)


@contextmanager
def _source(root,name):
    _safe_relative(name);fds=[]
    try:
        fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW);fds.append(fd)
        for part in name.split('/')[:-1]:fd=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd);fds.append(fd)
        fd=os.open(name.split('/')[-1],os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd);fds.append(fd)
        if not stat.S_ISREG(os.fstat(fd).st_mode):raise ValueError('source must be regular')
        yield fd
    except OSError as e:raise ValueError(str(e)) from e
    finally:
        for fd in reversed(fds):os.close(fd)


def _hash_file(path):
    if path.is_symlink() or not path.is_file():raise ValueError('object is not a regular file')
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def _manifest(store,digest):
    if not isinstance(digest,str) or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):raise ValueError('manifest digest required')
    path=store/'manifests'/f'{digest}.json'
    if _hash_file(path)!=digest:raise ValueError('manifest checksum mismatch')
    result=_read_json(path)
    if result.get('kind')!='explicit_delta_v1':raise ValueError('unsupported manifest')
    return result


def save_delta(root,store,paths,*,project_id,parent=None):
    """Copy explicitly changed files, preserving prior mappings; no scanning history.

    Requires quiescent writers or caller-produced immutable exports. Raw SQLite
    files are refused; use the existing journal's consistent snapshot procedure.
    Returned local durability never authorizes remote cleanup.
    """
    root=Path(root).absolute();store=_directory(store)
    if not isinstance(project_id,str) or not project_id:raise ValueError('project id required')
    if not isinstance(paths,list) or not paths or len(set(paths))!=len(paths):raise ValueError('distinct explicit source paths required')
    for name in paths:
        _safe_relative(name)
        if name.endswith(('.db','.sqlite','.sqlite3','-wal','-shm')):raise ValueError('raw database state requires a consistent native backup, not blind copying')
    _directory(store/'objects');_directory(store/'manifests')
    old=_manifest(store,parent) if parent else {'project_id':project_id,'files':{}}
    if old['project_id']!=project_id:raise ValueError('parent belongs to another project')
    files=dict(old['files']);added=0;count=0;changed=[]
    for name in paths:
        tmp=None
        try:
            with _source(root,name) as fd:
                before=os.fstat(fd);outfd,tmp=tempfile.mkstemp(prefix='.own-object-',dir=store)
                h=hashlib.sha256();size=0
                with os.fdopen(outfd,'wb') as out:
                    while chunk:=os.read(fd,65536):h.update(chunk);size+=len(chunk);out.write(chunk)
                    out.flush();os.fsync(out.fileno())
                after=os.fstat(fd)
                signature=lambda v:(v.st_dev,v.st_ino,v.st_size,v.st_mtime_ns,v.st_ctime_ns)
                if signature(before)!=signature(after):raise ValueError('source changed during snapshot')
            digest=h.hexdigest();dest=store/'objects'/digest
            try:os.link(tmp,dest);added+=size;count+=1
            except FileExistsError:
                if _hash_file(dest)!=digest:raise ValueError('existing object corrupted')
            record=dict(sha256=digest,size_bytes=size)
            if files.get(name)!=record:changed.append(name)
            files[name]=record
        finally:
            if tmp and os.path.exists(tmp):os.unlink(tmp)
    manifest=dict(kind='explicit_delta_v1',project_id=project_id,parent=parent,files=files)
    data=_json_bytes(manifest);digest=hashlib.sha256(data).hexdigest();path=store/'manifests'/f'{digest}.json'
    if path.exists():
        if _hash_file(path)!=digest:raise ValueError('existing manifest corrupted')
    else:_atomic_json(path,manifest)
    for dpath in (store/'objects',store/'manifests'):
        fd=os.open(dpath,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)
    return dict(manifest=digest,changed_paths=changed,objects_added=count,content_bytes_added=added,
                files_mapped=len(files),remote_verified=False,cleanup_authorized=False)


def restore_subset(store,manifest,destination,paths):
    store=Path(store).absolute();m=_manifest(store,manifest)
    if not isinstance(paths,list) or len(set(paths))!=len(paths):raise ValueError('distinct explicit restore paths required')
    for name in paths:
        _safe_relative(name)
        if name not in m['files']:raise ValueError('unknown required dependency')
    dest=_directory(destination)
    if any(dest.iterdir()):raise ValueError('restore destination must be empty; preserve existing work')
    restored=0;total=0
    for name in paths:
        record=m['files'][name];source=store/'objects'/record['sha256']
        if _hash_file(source)!=record['sha256'] or source.stat().st_size!=record['size_bytes']:raise ValueError('object checksum/size mismatch')
        target=dest/name;_directory(target.parent)
        with source.open('rb') as f,target.open('xb') as out:
            shutil.copyfileobj(f,out,65536);out.flush();os.fsync(out.fileno())
        if _hash_file(target)!=record['sha256']:raise ValueError('restored checksum mismatch')
        restored+=1;total+=record['size_bytes']
    return dict(files_restored=restored,content_bytes_restored=total,full_history_restored=False,remote_verified=False)


def adoption_report(project_version,available_version,*,active_attempts,user_paused,source_accessible):
    if type(active_attempts)is not int or active_attempts<0:raise ValueError('actual active/unknown attempt count required')
    status=('user_paused' if user_paused else 'waiting_for_skill' if not source_accessible else
            'wait_for_quiet_boundary' if active_attempts and project_version!=available_version else
            'migration_required' if project_version!=available_version else 'version_matches')
    return dict(status=status,project_version=project_version,available_version=available_version,
                adopted=False,scheduler_mutated=False,source_hash_verification_required=True)


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cgroup',default='/sys/fs/cgroup');a=p.parse_args()
    print(json.dumps(memory_snapshot(a.cgroup),indent=2,allow_nan=False))
if __name__=='__main__':main()
