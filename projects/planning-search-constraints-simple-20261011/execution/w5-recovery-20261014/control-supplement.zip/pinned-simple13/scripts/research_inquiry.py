"""Object-first inquiry checks within an existing research_decision.

Checks declared dependencies, history and task correspondence, not the truth,
originality, causal sufficiency or semantic diversity of an agent's hypotheses.
No candidate generator, probability model, scheduler or project state is created.
"""
from __future__ import annotations
from research_reasoning import Check, _text, _norm

STAGES = {'lead', 'hypothesis', 'construction'}
ENTRIES = {'mathematics', 'phenomenon', 'literature', 'mixed'}
ACTIONS = {'derive', 'probe', 'qualify', 'compare', 'repair', 'literature', 'park', 'retire', 'repeat', 'confirm'}
LAYERS = {'object', 'assumption', 'derivation', 'implementation', 'evaluation',
          'proxy_link', 'scope', 'value', 'infrastructure'}
STATUSES = {'open', 'supported', 'refuted', 'conflicting', 'parked', 'not_applicable'}


def evaluate(root, inquiry, *, decision, previous=None):
    """Return scoped record gaps and transitive references; retain incomplete science."""
    c = Check(root)
    i = inquiry if isinstance(inquiry, dict) else {}
    if not i:
        c.gap('inquiry_required', 'inquiry', 'Record the problem frame before choosing operations; a lead may have no completed derivation.')
        return c.report(stage=None, selected_action=None)
    for key in ('problem_id', 'frame_id', 'question', 'goal_preservation', 'selection_reason'):
        c.need(i.get(key), 'missing_inquiry_field', 'inquiry.' + key)
    if i.get('stage') not in STAGES:
        c.gap('inquiry_stage', 'inquiry.stage', 'Distinguish lead, hypothesis and construction; they are not scientific verdicts.')
    if i.get('entry') not in ENTRIES:
        c.gap('inquiry_entry', 'inquiry.entry', 'Both mathematical and phenomenon-first investigation are legitimate.')
    c.refs([i.get('goal_ref')], 'inquiry.goal_ref', required=True)
    objects = i.get('objects') if isinstance(i.get('objects'), dict) else {}
    for key in ('target', 'information', 'objective'):
        c.need(objects.get(key), 'missing_problem_object', 'inquiry.objects.' + key)
    # Representation/cost belong here only when consequential, not a six-box gate.
    for key in ('representation', 'cost_model'):
        if key in objects:
            c.need(objects[key], 'missing_problem_object', 'inquiry.objects.' + key)
    defaults = c.entries(i.get('defaults'), 'inquiry.defaults')
    if not defaults:
        c.need(i.get('no_default_reason'), 'unexamined_default', 'inquiry.no_default_reason')
    for name, default in defaults.items():
        c.need(default.get('statement'), 'missing_default', name)
        if default.get('status') not in {'open', 'supported', 'refuted'}:
            c.gap('default_status', name, 'Do not silently treat a plausible default as established.')
        c.refs(default.get('evidence_refs', []), name, required=default.get('status') in {'supported', 'refuted'})
    explanations = c.entries(i.get('explanations'), 'inquiry.explanations')
    for name, explanation in explanations.items():
        for key in ('mechanism', 'conditions', 'prediction'):
            c.need(explanation.get(key), 'missing_explanation', name + '.' + key)
        if explanation.get('status') not in STATUSES:
            c.gap('explanation_status', name, 'Keep unresolved, conflicting and refuted accounts distinct.')
        c.refs(explanation.get('evidence_refs', []), name, required=explanation.get('status') in {'supported', 'refuted', 'conflicting'})
    selected = c.ids(i.get('selected_explanation_ids'), 'inquiry.selected_explanation_ids')
    if not explanations:
        if i.get('stage') != 'lead':
            c.gap('missing_explanation', 'inquiry.explanations', 'Name the mechanism under test, or retain an unexplained empirical lead.')
        c.need(i.get('unexplained_lead'), 'unexplained_lead_missing', 'inquiry.unexplained_lead')
    elif not selected:
        c.gap('no_selected_explanation', 'inquiry.selected_explanation_ids', 'Name the account being investigated; this does not certify it.')
    for name in selected:
        if name not in explanations:
            c.gap('unknown_explanation', name, 'Select a recorded explanation.')
        elif explanations[name].get('status') in {'refuted', 'not_applicable', 'parked'}:
            c.gap('refuted_explanation_selected', name, 'Keep the old branch; select a justified successor or explicitly investigate the contradiction.')
    contrasts = c.entries(i.get('contrasts'), 'inquiry.contrasts')
    for name, contrast in contrasts.items():
        ids = c.ids(contrast.get('explanation_ids'), name + '.explanation_ids', True)
        if len(ids) < 2 or any(h not in explanations for h in ids):
            c.gap('contrast_explanation_binding', name, 'A rival contrast names at least two actual accounts, not a candidate-count requirement.')
        for key in ('intervention', 'held_fixed'):
            c.need(contrast.get(key), 'missing_contrast', name + '.' + key)
        predictions = contrast.get('predictions')
        if not isinstance(predictions, dict) or set(predictions) != set(ids):
            c.gap('contrast_prediction_binding', name, 'Bind a conditional prediction to every contrasted explanation.'); continue
        for h in ids:
            c.need(predictions[h], 'missing_contrast_prediction', name + '.' + h)
        if len({_norm(p) for p in predictions.values()}) < 2:
            c.gap('indistinguishable_contrast', name, 'Different names are not a discriminator; report equivalence or find a meaningful intervention.')
    contrast_id = i.get('selected_contrast_id')
    if contrast_id is not None and contrast_id not in contrasts:
        c.gap('unknown_selected_contrast', 'inquiry.selected_contrast_id', 'Select the actual intended comparison.')
    if len(explanations) > 1:
        if contrast_id is None or not set(selected).intersection(contrasts.get(contrast_id, {}).get('explanation_ids', [])):
            c.gap('missing_discriminator', 'inquiry.selected_contrast_id', 'Use a check that separates the consequential accounts before expanding.')
    elif explanations:
        c.need(i.get('no_alternative_reason'), 'missing_alternative_reason', 'inquiry.no_alternative_reason')
    priority = i.get('priority') if isinstance(i.get('priority'), dict) else {}
    for key in ('basis', 'uncertainty', 'decision_value', 'cost'):
        c.need(priority.get(key), 'missing_inquiry_priority', 'inquiry.priority.' + key)
    # No numeric score and no conversion of unknown into a low success probability.
    if any(k in priority for k in ('probability', 'posterior', 'bayes_factor')):
        c.gap('unsupported_probability', 'inquiry.priority', 'A quantitative discovery model needs separate calibration, not an invented confidence.')
    check = i.get('next_check') if isinstance(i.get('next_check'), dict) else {}
    action = check.get('action')
    if action not in ACTIONS:
        c.gap('inquiry_action', 'inquiry.next_check.action', 'Choose a bounded discriminator, derivation, acquisition, repair or scoped disposition.')
    c.need(check.get('question'), 'missing_next_question', 'inquiry.next_check.question')
    tasks = c.ids(check.get('task_ids'), 'inquiry.next_check.task_ids', True)
    if tasks != decision.get('selected_task_ids'):
        c.gap('inquiry_task_mismatch', 'inquiry.next_check.task_ids', 'The frame, decision and actual task must select the same work.')
    outcomes = check.get('outcome_actions') if isinstance(check.get('outcome_actions'), dict) else {}
    for outcome in ('supports', 'refutes', 'inconclusive', 'invalid'):
        c.need(outcomes.get(outcome), 'missing_inquiry_outcome', 'inquiry.next_check.' + outcome)
    c.refs(check.get('input_refs', []), 'inquiry.next_check.input_refs')
    if i.get('stage') != 'construction' and action in {'compare', 'confirm'}:
        c.gap('early_claim_expansion', 'inquiry.next_check.action', 'A lead/hypothesis uses a diagnostic probe, not comparative method certification or confirmation.')
    observations = i.get('observations')
    if not isinstance(observations, list):
        c.gap('missing_observations', 'inquiry.observations', 'Keep [] before execution and append actual scoped outcomes after it.'); observations = []
    observation_ids, attempts = [], set()
    for observation in observations:
        if not isinstance(observation, dict):
            c.gap('invalid_observation', 'inquiry.observations', 'Record the real attempt and its interpretation.'); continue
        name = observation.get('id'); attempt = observation.get('attempt_id')
        if not _text(name) or name in observation_ids:
            c.gap('duplicate_identity', 'inquiry.observations', 'Use distinct observation IDs.')
        observation_ids.append(name)
        if not _text(attempt) or attempt in attempts:
            c.gap('duplicate_inquiry_attempt', str(name), 'One receipt is one attempt, not repeated independent evidence.')
        if isinstance(attempt, str): attempts.add(attempt)
        for key in ('task_id', 'interpretation'):
            c.need(observation.get(key), 'missing_inquiry_observation', str(name) + '.' + key)
        c.refs([observation.get('receipt_ref')], str(name) + '.receipt_ref', required=True)
        affected = c.ids(observation.get('affected_explanation_ids'), str(name) + '.affected_explanation_ids')
        if any(h not in explanations for h in affected):
            c.gap('unknown_affected_explanation', str(name), 'Preserve the account affected by this observation.')
        outcome, layer = observation.get('outcome'), observation.get('affected_layer')
        if outcome not in {'supports', 'refutes', 'inconclusive', 'invalid'} or layer not in LAYERS:
            c.gap('invalid_observation_scope', str(name), 'Classify both the outcome and the affected object.')
        if outcome == 'invalid' and layer not in {'implementation', 'evaluation', 'infrastructure'}:
            c.gap('invalid_run_is_not_refutation', str(name), 'An invalid execution diagnoses implementation/evaluation/infrastructure, not the mathematical hypothesis.')
    if i.get('based_on_observation_ids') != observation_ids:
        c.gap('inquiry_feedback_not_consumed', 'inquiry.based_on_observation_ids', 'Account for all retained results, including negative and invalid runs.')
    if previous:
        if previous.get('goal_ref') != i.get('goal_ref'):
            c.gap('inquiry_goal_changed', 'inquiry.goal_ref', 'Retain the original user-goal source; explicit host goal revision is separate.')
        if previous.get('objects') != objects:
            if previous.get('frame_id') == i.get('frame_id'):
                c.gap('frame_reused_after_object_change', 'inquiry.frame_id', 'An object/information/target change needs a new frame ID, not a renamed operation.')
            c.need(i.get('change_reason'), 'frame_change_reason_missing', 'inquiry.change_reason')
        old_observations = previous.get('observations', [])
        if not isinstance(old_observations, list) or observations[:len(old_observations)] != old_observations:
            c.gap('inquiry_history_lost', 'inquiry.observations', 'Preserve the immutable prefix; re-evaluation appends an observation rather than erasing it.')
        for prior in previous.get('explanations', []):
            old_id = prior.get('id'); now = explanations.get(old_id)
            if now is None:
                c.gap('explanation_history_lost', str(old_id), 'Keep parked, rejected and alternative branches.')
                continue
            if any(now.get(k) != prior.get(k) for k in ('mechanism', 'conditions', 'prediction')):
                c.gap('explanation_rewritten', str(old_id), 'Changed mathematical content uses a new explanation ID; preserve its predecessor.')
            if prior.get('status') == 'refuted' and now.get('status') not in {'refuted', 'conflicting', 'parked'}:
                c.gap('refutation_erased', str(old_id), 'Later evidence cannot silently erase a refutation; retain the conflict or add a scoped successor.')
    return c.report(stage=i.get('stage'), selected_action=action, selected_task_ids=tasks,
                    explanation_count=len(explanations), contrast_count=len(contrasts),
                    semantic_diversity_verified=False, discovery_probability_computed=False)
