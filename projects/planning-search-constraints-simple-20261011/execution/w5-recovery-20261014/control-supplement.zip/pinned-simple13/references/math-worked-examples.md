# Worked examples: derivation to empirical question

Contents:
- Constant scaling versus reweighting
- Bounding a mixed-teacher reward
- Dense signals versus temporal credit
- Deriving a geometric mixture
- Logit geometry versus parameter geometry

These examples demonstrate reasoning patterns. They do not establish novelty
or empirical effectiveness. Recheck the target paper's version and actual
implementation before attributing a result to it.

## Constant scaling versus reweighting

For plain SGD on a differentiable objective, scaling the entire loss by c > 0
gives

$$
\theta^+=\theta-\eta\nabla(cL)=\theta-(\eta c)\nabla L.
$$

This is an exact update identity under the same samples and with no other
unscaled terms. It is not a general statement about all optimizers. Clipping,
regularization, finite precision and optimizer state can break a proposed
equivalence. Ideal Adam without its epsilon can cancel a positive global
gradient scale through consistently scaled first/second moments; that is a
different invariance from multiplying its learning rate by c.

For linked diffusion predictions

$$
x_t=\alpha_t x_0+\sigma_t\epsilon,\qquad
\widehat x_0=(x_t-\sigma_t\epsilon_\theta)/\alpha_t,
$$

with nonzero alpha,

$$
\|\widehat x_0-x_0\|^2
=\frac{\sigma_t^2}{\alpha_t^2}\|\epsilon_\theta-\epsilon\|^2.
$$

The predictions determine one another at a fixed t when alpha and sigma are
nonzero, but unweighted losses over t generally optimize different weightings.
Independent model parameterizations can introduce additional differences.
At alpha = 0 the displayed conversion is undefined.

Empirical bridge: a reported change in performance across timesteps may arise
from weighting, representation or optimization. Compare matched weights before
crediting a new representation. Predict which timestep contributions change
from the derived factor; use the actual scheduler and native evaluation.

## Bounding a mixed-teacher reward

Let p-bar be a frozen student distribution with common positive support with q.
For 0 < a < 1, define q-tilde = (1-a)p-bar + a q and
r = log(q/p-bar). On samples from p-bar,

$$
\widetilde r=\log(1-a+a e^r)\geq\log(1-a),\qquad
\frac{d\widetilde r}{dr}=\frac{ae^r}{1-a+ae^r}.
$$

This is an exact pointwise lower bound and an exact derivative. Very negative
ratios are compressed; the local slope at r = 0 is a. There is no corresponding
finite uniform upper bound over arbitrary distributions as r tends to infinity.

It does not follow that the neural parameter gradient is bounded: the score
or Jacobian and the positive tail still matter. At a = 0 the signal is zero;
zero variance alone is not an improvement. At a = 1 the original ratio returns.

Empirical bridge: separately measure negative-tail compression, effective
signal scale and useful progress. Match an appropriate scale-control condition
to distinguish robustness from simply reducing the update. A theorem on
variance needs its own moment/score/horizon assumptions.

Related reading: [TOP-D, P1](https://arxiv.org/abs/2607.04751).
The calculation here isolates one mathematical mechanism, not the paper's
entire algorithm or convergence claim.

## Dense signals versus temporal credit

Fix a teacher q and a finite trajectory distribution p-theta. Assume common
positive support and conditions permitting differentiation under expectation.
Let h-t be the prefix, s-t the score of the current token, and

$$
r_t=\log\frac{q(y_t\mid h_t)}{p_\theta(y_t\mid h_t)},\qquad
J=-D_{\rm KL}(p_\theta(y)\|q(y))=\mathbb E_{p_\theta}\sum_t r_t.
$$

The direct derivative of the log-p reward has zero expectation by the
score identity. Conditioning eliminates past rewards, giving

$$
\nabla J
=\mathbb E\sum_t s_t\left(\sum_{u=t}^T r_u\right).
$$

The undiscounted return therefore contains the current term and all future
terms. An update using only s-t times r-t is generally a different,
frozen-prefix surrogate. Token-level feedback does not remove temporal credit
assignment. Check the code before deciding which gradient an OPD implementation
uses; truncation, weighting and clipping can change the comparison.

Do not immediately conclude that the omitted term explains every stall.
For a realizable teacher at a smooth interior optimum theta-star, fixed finite
horizon and delta = theta - theta-star,

$$
D_{\rm KL}(p_\theta\|q)
=\tfrac12\delta^\top F\delta+O(\|\delta\|^3).
$$

Under the same regularity, conditional future KLs are second order and
the expected omitted future term is O(||delta||^2). Along directions of
nonzero Fisher curvature, the total gradient has a first-order leading term.
Null directions, unattainable teachers, nonuniform support or growing horizons
need separate analysis.

Empirical bridge: “closer models stall because future terms dominate” is not a
general consequence of the decomposition. Distinguish normal vanishing
gradients, estimator bias, noise and conditioning. Compare size, direction
and uncertainty of the local and future components before choosing a remedy.
An algebraic finite-trajectory check verifies the identity, not task utility.

## Deriving a geometric mixture

Consider a finite common support and the constrained behavior-distribution
problem

$$
\min_\mu D_{\rm KL}(\mu\|q)
\quad\text{subject to}\quad D_{\rm KL}(\mu\|p)\leq\varepsilon.
$$

Adding a multiplier lambda >= 0 and a normalization multiplier yields
stationarity

$$
(1+\lambda)\log\mu-\log q-\lambda\log p+\text{constant}=0.
$$

Consequently, for finite lambda,

$$
\mu_\beta=\frac{p^{1-\beta}q^\beta}{Z(\beta)},
\qquad \beta=(1+\lambda)^{-1}.
$$

The multiplier is chosen for feasibility/complementarity, not merely named a
trust-region parameter. With f = log(q/p),

$$
\frac{d}{d\beta}D_{\rm KL}(\mu_\beta\|p)
=\beta\,\operatorname{Var}_{\mu_\beta}(f)\geq0.
$$

The constraint gives an interpretable way to choose beta. Endpoints, inactive
constraints, truncated support and numerical approximations need checking.
This construction differs from arithmetic mixing of a training target.

Empirical bridge: predict how measured behavior drift changes with beta,
then check whether the implementation realizes that distribution. Separate
improved exploration from target regularization.

Related reading: [TRB, P2](https://arxiv.org/abs/2605.31159).

## Logit geometry versus parameter geometry

For a unit direction d, lambda >= 0 and logit-space gradient g, define
P = I + lambda d d-transpose. Then

$$
g^\top Pg=\|g\|^2+\lambda(d^\top g)^2,\qquad
Pg=0\ \Longleftrightarrow\ g=0.
$$

Those are logit-space statements. For a model Jacobian A, the parameter
gradients are A-transpose g and A-transpose P g. They need not vanish at the
same parameters. For example,

$$
A=\begin{pmatrix}1\\0\end{pmatrix},\quad
g=\begin{pmatrix}0\\1\end{pmatrix},\quad
P=\begin{pmatrix}2&1\\1&2\end{pmatrix}
$$

gives A-transpose g = 0 but A-transpose P g = 1, despite P being positive
definite and of the stated rank-one-update form.

Empirical bridge: distinguish a claim about logit directions from a claim
about neural optimization. Measure the induced parameter update and its
alignment with the actual objective. The counterexample limits a theorem;
it does not demonstrate that a method performs badly.
