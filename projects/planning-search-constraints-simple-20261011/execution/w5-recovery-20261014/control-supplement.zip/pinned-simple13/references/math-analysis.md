# Mathematical structure analysis and method discovery

Develop mathematical understanding and empirical understanding together. Either
can initiate inquiry; each should challenge and refine the other. A benchmark gap
is one possible starting point. An equivalence, a missing gradient term, a
surprising scale dependence or a limitation of an assumption is another.

## Working contract

Both Web and Local must follow the actual mathematical/source/selection
obligations when generating or revising an idea. In the default split Web performs
this reasoning and generates the implementation/design; Local tests it. Web's
source review or mathematical argument is not a software-test receipt or an
empirical result. Use workflow-harness.md's role-specific handoff and preserve
conditional assumptions and pending empirical confirmation.

- Apply this contract while generating the idea, including a chat-only answer.
  Read the relevant primary derivation, actual code and native benchmark contents
  for empirical investment, reusing current inspected sources. Select applicable
  operations and carry out their steps; a proposed module with future mathematics
  is not a completed candidate. Use method-verification.md for new/reopened pool
  generation, per-card review, full ranking and top-15 selection before code.
- Deliver the agent-produced math cards, source locators and actual review/ranking
  status. If a proof step, condition or distinct construction is missing, keep it
  as a lead and investigate it; do not make the user write the analysis, pad the
  pool, fabricate a review or proceed to candidate code. Reuse valid prior cards
  and ranking on continuation instead of restarting the whole pool.
- Use this internal procedure as the mathematical core for every proposed research idea.
  Perform relevant mathematical analysis before presenting a candidate; naming
  this procedure or promising to derive the mechanism later does not satisfy it.
  A raw observation or attractive mechanism without this analysis remains an
  investigation lead, not a research candidate ready to recommend.
- For each candidate, provide its formal object, selected mathematical move,
  consequential derivation, assumptions, distinguishing prediction and falsifier,
  and explain how the result motivates the proposed construction or claim.
  In a batch, cover every candidate. Shared derivations may be referenced, but
  each idea needs its own implication and prediction.
- Use the material already available. Reading, derivation and conceptual analysis
  can proceed without a selected benchmark, compute budget or project repository.
- Distinguish measured observations, user reports, conjectures, exact identities,
  conditional results and approximations. Never invent the missing half.
- Do not impose a theory-first or experiment-first sequence, equal time allocation,
  mandatory multiagent execution or a requirement to prove a theorem for every idea.
- Equations must change the explanation, prediction or method choice. A familiar
  reformulation can clarify a problem without constituting a novel contribution.
- Simple baselines test necessity and competing explanations. They do not define
  the sole source of ideas. Strong empirical discoveries can motivate new theory.

## 1. Locate the question and the mathematical objects

State the unresolved question, the strongest available evidence and what remains
unknown. Include success regimes as well as failure regimes. A reported pattern
is a hypothesis to verify, not an established mechanism.

Separate, when applicable:

| Object | Questions |
|---|---|
| Scientific objective | What distribution, function or capability should improve? |
| Sampling process | Which measure generates data, states or trajectories? Does it depend on the parameters? |
| Estimator or derivative | Which expectation, gradient, surrogate or approximation is computed? |
| Actual update | What do stop-gradient, normalization, clipping, optimizer state and implementation change? |

Record the relevant support, horizon, parameterization, units, conditioning,
available information and assumptions. Use only the objects the problem needs.
An objective equivalence does not establish estimator, update or trajectory
equivalence.

## 2. Select mathematical moves and actually perform them

Read the navigation rules in
[math-operation-graph.md](math-operation-graph.md), then only the relevant
families and conditional connections. Its 48 operations cover scale, probability,
bounds, constraints, estimators, algebraic computation, dynamics and
identifiability. Choose moves by their input object and unresolved question;
do not enumerate techniques or traverse every node as a checklist.

Use [math-derivation-paths.md](math-derivation-paths.md) for 14 composable
trajectories, and [math-paper-atlas.md](math-paper-atlas.md) for their 20 primary
ICML/NeurIPS examples, reading scope and limitations. These paths reconstruct
mathematical dependencies; they do not establish novelty or the authors' private
discovery process. Read the original derivation when the current claim depends
on it. [math-analysis-moves.md](math-analysis-moves.md) supplies further guidance
on bounds, equivalence, asymptotics and counterexamples.

| Clue | Useful moves |
|---|---|
| Sensitivity to length, temperature, dimension or magnitude | Scaling, nondimensionalization, relative orders |
| Exploding values or an intractable objective | Upper/lower bounds, tightness, surrogate construction |
| Two methods appear equivalent | Change of variables, exact identities, derivative comparison |
| A hidden interaction or unexplained error | Decomposition, conditioning, telescoping, bias and variance |
| A tradeoff or apparently arbitrary mixing rule | Constrained optimization, Lagrangians, duality, variational calculus |
| Behavior changes near a limit or equilibrium | Taylor/perturbation expansion, asymptotics, stability |
| Progress depends strongly on direction or representation | Spectrum, conditioning, invariance, identifiability |
| An attractive universal explanation | Boundary cases, minimal counterexamples, impossibility arguments |

For each chosen move, show the consequential steps. State what is preserved,
what is changed or discarded, the equality/tightness conditions, and the
assumptions needed for the conclusion. Differentiate through parameter-dependent
measures unless explicitly analyzing a frozen-distribution surrogate.
Connect moves only when the previous result supplies the next input and its
condition is established or explicitly conditional. Carry errors and assumptions
forward. If a condition fails, branch, backtrack or narrow the claim; do not
declare it true to complete a preferred path. New connections are welcome when
their compatibility and mathematical justification are supplied.

Use [math-worked-examples.md](math-worked-examples.md) when the question involves
distillation, scale equivalence, reward bounds, policy gradients or logit geometry.
These are examples of reasoning, not templates to force onto every domain.
For the supplied TOP-D/TRB/ERPD/TrOPD papers and the two OPRD titles, also read
[math-opd-reading-audit.md](math-opd-reading-audit.md): it separates constructions,
surrogate choices and independently checked limitations of the written claims.

## 3. Connect derivations and observations in both directions

Develop competing explanations when the mechanism is uncertain. For each, ask:

1. What mathematical statement would make this explanation plausible?
2. What observation would distinguish it from the nearest alternative?
3. Which regime should strengthen, weaken, eliminate or reverse the effect?
4. Which result would make us revise the explanation or abandon the idea?

A derivation should predict something beyond “the proposed method works better”:
a dependence, invariant, sign, relative order, threshold, failure boundary or
direction of change. An observation should be able to expose a missing term,
violated assumption, inappropriate scale or insufficient model.

When evidence contradicts a prediction, check measurement and implementation,
then revise or reject the explanation. Do not add assumptions solely to protect
the preferred story. When no experiments are available, deliver the valid
derivation and discriminating predictions with their evidential status.

## 4. Turn understanding into a research decision

A method proposal must follow from the identified structure: explain why the
construction addresses the derived issue, what tradeoff it introduces, and when
it should not help. “Add memory/a critic/a regularizer” is not a derivation.
Methods may change objectives, probability spaces, representations, estimators,
constraints, solvers or multi-stage algorithms. There is no preference for
one-line modifications and no requirement to begin with a failed benchmark.
Useful outcomes also include an equivalence result, a counterexample, a refined
measurement, a boundary of applicability or a justified decision not to change
the method.

Audit the algebra with an independent route when a central conclusion warrants
it: special cases, symbolic calculation, exhaustive finite examples or numerical
derivative checks. These verify mathematics or implementation; they are not
benchmark evidence, and numerical checks do not prove a general theorem.

For empirical claims, use existing published tasks, native metrics and capable
baselines under the research quality contract. Choose comparisons that separate
mechanisms, control relevant budgets and report uncertainty. Missing suitable
evaluation assets require source/access work or an unresolved measurement gap;
do not invent benchmark cases, labels, metrics or scorers.
“Minimal intervention” means avoiding unnecessary confounding in a decisive
comparison; it does not cap method complexity, sample size, repetitions or the
scope of validation needed to support a claim.

Check primary literature before claiming novelty. Read a paper's actual
derivation, assumptions and algorithm, not just its abstract or theorem label.
Do not inherit an invalid proof because it appears in a published paper.

## Output and collaboration

Use the compact, adaptable record in [math-handoff.md](math-handoff.md).
Lead with the new understanding; present enough derivation to assess it. Avoid
dumping a checklist or making a list of mathematical names stand in for reasoning.
The mathematical basis is mandatory for a proposed research candidate. Conditional
results and unresolved proofs must remain labeled; do not fill a missing basis
with decorative equations or a fabricated theorem. Reuse an inspected valid
analysis when its objective, assumptions and claim are unchanged, and re-analyze
the affected parts after a substantive revision.

This is a built-in part of research-autopilot. Contribute the analysis directly
to the current H01/H03/M02 idea and method records, with the same project state,
priorities, empirical gates and execution workflow. It requires no separate skill
installation or invocation. Do not apply empirical execution gates to read-only
mathematical exploration.
