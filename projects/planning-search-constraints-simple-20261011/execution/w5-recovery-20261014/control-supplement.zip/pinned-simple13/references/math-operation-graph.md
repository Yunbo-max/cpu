# Conditional graph of mathematical operations

This is a navigation graph, not a checklist or an automatic theorem prover.
The 48 operations below are reusable mathematical moves. Their grouping and
connections are our synthesis; paper examples do not establish every proposed
connection. Source IDs refer to [math-paper-atlas.md](math-paper-atlas.md).

## How to navigate

1. Start with an uncertainty and an explicit object: objective, probability
   measure, estimator, update field, representation, constraint or computation.
   Either observations or mathematics can supply the uncertainty.
2. Choose a plausible entry below. Read only its family and relevant paper/path.
3. Perform the operation. Keep an artifact: an equation, identity, bound,
   counterexample, decomposition or algorithm with its derivation.
4. Take a connection only when its input exists and its condition has evidence.
   Mark the condition **established**, **conditional** or **false**. A conditional
   edge may guide investigation, but its conclusion remains conditional. A false
   edge requires a different route; writing an assumption does not establish it.
5. Carry forward support, units, parameter dependence, approximation errors,
   equality conditions and the space in which a statement holds. Every new
   approximation adds an obligation; later algebra does not erase it.
6. End when the consequential uncertainty is resolved enough for a construction,
   prediction, impossibility result or rejection. There is no node-count quota.
   Re-enter at the affected object when evidence or the method changes.

Output types in the tables are descriptive, not software-enforced types. An
edge's output must supply the next operation's actual input. Missing material
requires an intermediate derivation, not a jump justified by shared vocabulary.
Paths may branch, merge or loop. The connection table is open: a new connection
is valid when its input/output compatibility and mathematical condition are
explicitly derived. It is not necessary for a good idea to copy a published path.

## A. Scale, coordinates and normalization

| ID / operation | Input → mathematical output | Conditions and obligations |
|---|---|---|
| A01 Dimensional analysis / 无量纲化 | Variables, units and governing equations → dimensionless groups and scale predictions. | Transform coordinates, time, measures and coefficients together; identify independent ratios. A change of units is not a change of the physical problem. |
| A02 Global rescaling / 整体缩放 | `L` → `cL`, transformed gradient and update. | Fixed `c>0` preserves minimizers. SGD equivalence needs learning-rate compensation; Adam epsilon, clipping, regularization and optimizer state require separate analysis. |
| A03 Relative weighting / 相对权重 | A sum or integral of terms → effective weight per sample, token, scale or task. | Nonconstant weights generally change the objective. Sum versus mean at variable lengths is not a global scalar. Carry sampling probabilities into effective weights. S13, S15. |
| A04 Differentiate adaptive weights / 自适应权重求导 | `w(theta)L(theta)` → `w grad L + L grad w`, or a specified detached field. | Identify all parameter-dependent weights and statistics. Detachment is an algorithmic choice whose fixed points need analysis. |
| A05 Center, whiten, precondition / 中心化与白化 | Means/covariances and signal/noise scales → transformed inputs, targets and metric. | State population versus batch statistics, singular directions, epsilon and test-time behavior. Unit variance is not independence; reduced activation gradients need not prove faster training. S09, S15. |
| A06 Change coordinates / 变量替换 | `x=T(z)` or a new model parameter → transformed objective, density and derivatives. | Check invertibility/domain, Jacobians and representable function class. A bijection preserves an optimization problem's solutions but not Euclidean gradient trajectories. S13. |

## B. Probability structure and information

| ID / operation | Input → mathematical output | Conditions and obligations |
|---|---|---|
| B01 Rewrite likelihood, KL, reward or energy / 等价改写 | An objective → an identity exposing log-ratios, entropy or reward. | Preserve signs, expectation measure and constants dependent on optimized parameters. Distinguish equality of values, gradients, optima and updates. S02. |
| B02 Analyze the partition function / 配分函数 | Unnormalized weights → normalized distribution, `log Z` derivatives and moments. | `Z` must be finite and positive. Cancellation requires the same additive term in the same conditioning context. An unbiased numerator and denominator do not give an unbiased ratio. |
| B03 Change measure / 重要性采样 | `E_p f` → `E_q[(p/q)f]` and its variance. | Require `p` absolutely continuous with respect to `q` for relevant contributions. Clipping and self-normalization introduce bias; absent support cannot be repaired by large weights. S14. |
| B04 Factorize, telescope and assign credit / 分解与望远镜求和 | Joint/trajectory quantity → conditional terms or reward-to-go. | Keep terminal terms, EOS, horizon, discount and parameter-dependent sampling. Token-local signals and suffix returns need not yield the same gradient. See math-worked-examples.md. |
| B05 Condition and marginalize / 条件化与边缘化 | Joint law → conditional expectation, marginal objective or variance decomposition. | Check tractability and cross terms. Integrating a component analytically is different from conditioning the entire estimator. S05. |
| B06 Coarse-grain a probability space / 概率空间聚合 | A partition of outcomes → aggregate masses and lost distinctions. | Establish what the downstream objective sees and what becomes unidentifiable. Preserving aggregate mass is not preserving within-cell probabilities. S19. |

## C. Bounds, decompositions and local approximations

| ID / operation | Input → mathematical output | Conditions and obligations |
|---|---|---|
| C01 Variational/Jensen construction / 变分界 | An intractable marginal or log integral → tractable bound and explicit gap. | Derive direction, equality condition and support. A tighter objective can have a worse estimator. S04, S13. |
| C02 Convex conjugacy / 共轭表示 | A convex function → a variational primal/dual representation. | Check convexity, domain, closure and attainment; exchanging min and max needs a theorem, not algebra alone. |
| C03 Majorization/minorization / 接触界 | A difficult objective → a touching surrogate or controlled improvement bound. | Match bound direction to optimization and require touching at the current point. Merely lowering an upper bound need not lower the original objective. S01. |
| C04 Error decomposition / 误差拆解 | Total discrepancy → approximation, estimation, optimization and numerical terms. | Keep covariance/cross terms or justify their removal. Define the norm and whether a statement is pointwise, expected or uniform. |
| C05 Taylor, perturbation and delta method / 展开 | A smooth object near a specified point → leading terms and remainder. | Name the small parameter and expansion point; require appropriate derivatives/moments. Ratios near a vanishing denominator need separate treatment. S04, S16. |
| C06 Asymptotics and matched limits / 渐近与极限 | A family indexed by horizon, noise, dimension or sample count → dominant orders and regimes. | State what is held fixed and whether limits commute. Vanishing absolute error can still dominate a faster-vanishing signal. S04. |

## D. Constraints and optimization geometry

| ID / operation | Input → mathematical output | Conditions and obligations |
|---|---|---|
| D01 Lagrangian / KKT / 变分法 | A constrained objective → stationarity, feasibility, complementary slackness and dual variables. | Stationarity is not sufficient without suitable convexity; strong duality needs conditions. Separate boundary from interior solutions. S03, S20. |
| D02 Solve a distributional optimum / 分布空间求解 | Entropy/KL stationarity → normalized Gibbs, geometric mixture or transport factors. | Derive normalization and positivity rather than omit them. Distribution-space optima may not be representable by a neural model. S02, S03, S20. |
| D03 Dual sensitivity and budget calibration / 对偶校准 | A dual function or constrained family → coefficient from a budget. | Prove monotonicity/convexity before bisection/Newton; handle inactive constraints and endpoint solutions. Estimating a budget on samples changes guarantees. S20. |
| D04 Bregman proximal / mirror update / 镜像与近端 | A linearized objective and divergence → a geometry-aware update. | Specify divergence orientation, domain and exact versus approximate subproblem solution. Link to an actual descent/regret statement under its assumptions. S01, S08. |
| D05 Curvature and metric / 曲率与度量 | Local KL/Hessian/Jacobian → a metric, spectrum or preconditioned direction. | Fisher, empirical Fisher and Hessian are not interchangeable. A logit-space result must be pulled back through the model Jacobian. S07. |
| D06 Matrix/tensor factor approximation / 矩阵分解近似 | An expensive metric/operator → tractable blocks, Kronecker factors or tensor powers. | State where factorization is exact versus an approximation; audit damping, inverse roots, cost and directions discarded. S07, S08. |

## E. Gradients and stochastic estimators

| ID / operation | Input → mathematical output | Conditions and obligations |
|---|---|---|
| E01 Differentiate a parameter-dependent measure / 全梯度 | `E_p(theta) f(theta)` → score term plus direct derivative. | Justify differentiation under the integral; handle moving support/boundaries. Freezing the sampling law defines a different surrogate. |
| E02 Score/pathwise decomposition / 梯度分解 | A reparameterized stochastic objective → path derivative and score contributions. | Require differentiability/integrability; discrete draws require another construction. Check which zero-mean identity is valid under which measure. S05. |
| E03 Control variates and coupling / 控制变量 | An estimator and known-mean quantity → unbiased corrected estimator with covariance analysis. | For `g-a h`, derive variance including covariance and the optimal coefficient where meaningful. Zero mean alone does not ensure variance reduction; fitting on the same batch can alter bias. S06. |
| E04 Rao–Blackwellization / 条件期望降方差 | A square-integrable estimator `g` → `E[g|F]`. | Conditioning the whole estimator weakly reduces covariance. Replacing only one addend can destroy cancellation with other addends. S05 motivates this distinction. |
| E05 Relax and debias / 松弛与去偏 | A discrete problem plus continuous relaxation → biased surrogate or corrected unbiased estimator. | Keep the conditional relaxation law and compensating derivatives. Lower temperature does not by itself give useful finite-variance gradients. S06. |
| E06 Signal-to-noise and allocation / 信噪比与预算 | Means, covariance and evaluation cost → useful SNR and resource allocation. | Specify parameter block/direction and fixed total budget. Loss-optimal sampling and gradient-variance-optimal sampling are different objectives. S04, S14. |

## F. Algebraic structure and computation

| ID / operation | Input → mathematical output | Conditions and obligations |
|---|---|---|
| F01 Kernel/spectral representation / 核与谱表示 | A kernel → features or a spectral expectation. | Bochner needs a continuous positive-definite shift-invariant kernel; finite random features introduce error. Do not call a different kernel an exact softmax rewrite. S10, S11. |
| F02 Associativity and contraction order / 结合律 | A valid factorization → reordered matrix/tensor computation. | Preserve masks, normalizer and dimensions; mathematical equality does not imply identical floating-point behavior. Count intermediate memory, not only flops. S11. |
| F03 Sufficient state / prefix recurrence / 充分状态 | A causal sum or separable history dependence → finite recurrent statistics. | Prove the state retains everything the proposed output uses. Feature dimension/state capacity and numerical accumulation affect the benefit. S11. |
| F04 Low-rank product identities / 低秩连乘 | Products of identity-plus-low-rank factors → compact block form or triangular solve. | Preserve order: matrix products do not commute. Generalized Householder factors need not be orthogonal. S18. |
| F05 Block and alternating optimization / 分块交替 | A coupled problem → conditional subproblems and update schedule. | Separate exact coordinate descent, approximate updates and heuristics; bound stale-variable error or monitor it. An arbitrary phase split is not a derivation. S03 supplies a special scaling example. |
| F06 Eliminate variables / Schur complement / 消元 | A block system or jointly quadratic subproblem → reduced system and reconstruction. | Require invertibility or a justified pseudoinverse; account for fill-in, conditioning and the cost of reconstructing eliminated variables. |

## G. Dynamics, solvers and invariants

| ID / operation | Input → mathematical output | Conditions and obligations |
|---|---|---|
| G01 Fixed-point reformulation / 不动点 | A repeated computation → `z=f(z,theta)` and residual. | Existence, uniqueness, finding a root and convergence of naive iteration are distinct questions. S12. |
| G02 Implicit differentiation / 隐式求导 | A differentiable root equation → a linear system for sensitivities/adjoints. | Require a nonsingular relevant Jacobian locally; check root and linear-solve residuals. An inaccurate solve biases the gradient. S12. |
| G03 Stability / contraction / 稳定性 | Update Jacobian or differential equation → local stability or contraction region. | Spectral radius below one supports local iteration stability under regularity; a global contraction needs a domain-wide bound. Nonnormal transients require care. |
| G04 Integrating factor / variation of constants / 常数变易 | A semilinear ODE → exact linear evolution and nonlinear residual integral. | Require a tractable propagator and correct coefficient signs. Exact treatment of one part does not make the full numerical solution exact. S16. |
| G05 Time transformation and quadrature / 时间换元 | A residual integral → simpler time coordinate and controlled approximation. | Require monotonic invertible time map and regularity in the transformed coordinate; count evaluations and remainder. S16. |
| G06 Trajectory invariant plus boundary / 轨迹不变量 | A flow → a map constant along trajectories with an anchoring boundary. | An invariant without a boundary can collapse to a constant. Estimated flows and discrete pairs introduce approximation obligations. S17. |

## H. Identifiability, existence and adversarial checks

| ID / operation | Input → mathematical output | Conditions and obligations |
|---|---|---|
| H01 Symmetry / gauge quotient / 对称性 | A transformation group leaving observations/objective unchanged → equivalence classes and a gauge choice. | Verify invariance and recoverability; fixing a gauge must not remove scientifically distinct solutions. S02 gives a context-dependent reward-offset example. |
| H02 Nullspaces and identifiability / 可识别性 | Observation or gradient map → indistinguishable directions and needed information. | Distinguish observation insufficiency from optimization failure. A parameter-space claim requires analyzing the parameterization. S19. |
| H03 Population versus empirical problem / 总体与有限样本 | Population derivation → empirical objective with explicit coverage and approximation changes. | A finite dataset can alter support, existence and regularization, not only add variance. S19, S20. |
| H04 Boundary growth and existence / 边界与最优解存在性 | Objective near domain boundary/infinity → coercivity/barrier argument or nonattainment. | Compare competing divergence rates and domain compactness; an infimum need not be attained. S19. |
| H05 Audit the actual gradient field / 更新场审计 | Detached/clipped/custom update → exact vector field and fixed-point conditions. | For a potential claim check integrability on an appropriate domain. Gradient agreement in expectation is not equality per sample or trajectory. S20. |
| H06 Construct a counterexample / 反例构造 | A universal claim → a minimal admissible model testing its assumptions. | Preserve the claim's assumptions; one valid counterexample refutes universality but does not establish prevalence. Use finite states, rank-deficient Jacobians or limit cases. |

## Conditional connections

These are reusable choices, not obligations to traverse every row. “Otherwise”
is a research action, not a license to assume the condition true. Audit every
chosen operation against its own obligations in addition to the connection.

| From → to | Take this connection when… | Otherwise / backtrack |
|---|---|---|
| A01 → A02 | Every term acquires the same fixed positive multiplier. | A03 for relative changes. |
| A01 → A03 | Terms scale with different powers or length factors. | Derive missing units before weighting. |
| A01 → A05 | Input/target variance spans incompatible scales. | Test whether the problem is directional curvature at D05. |
| A02 → H05 | Claim concerns the implemented optimizer. | Restrict claim to minimizers. |
| A03 → A04 | A proposed weight depends on current parameters. | Treat it as external, but still inspect sampling at B03. |
| A03 → B03 | Reweighting might be implemented by a proposal distribution. | Keep it as a changed objective. |
| A04 → H05 | A derivative is removed, clipped or modified. | Retain the full derivative. |
| A05 → A06 | The normalization can be expressed as a coordinate/target map. | Analyze batch dependence directly via E01/H05. |
| A06 → A03 | Squared residuals or Jacobians induce scale-dependent factors. | Prove any claimed objective equality directly. |
| A06 → D05 | Equivalent representations train differently. | First rule out objective or estimator changes. |
| B01 → B02 | Exponentiation produces an unnormalized measure. | Retain constants in the original representation. |
| B01 → B04 | The joint law factorizes along a causal sequence. | Do not invent token credit from a sequence scalar. |
| B01 → D01 | The rewrite exposes an explicit tradeoff/constraint. | Investigate as an equivalence result first. |
| B02 → H01 | An additive offset cancels within a shared conditioning context. | Keep the partition term. |
| B02 → D03 | A partition derivative represents a constraint moment. | Derive a different solver; do not assume monotonicity. |
| B03 → E06 | Support is adequate but weight variance or cost is large. | Repair support or narrow the estimand before allocation. |
| B04 → E01 | Sampling depends on the learned policy. | Differentiate the specified frozen-law surrogate. |
| B05 → E04 | The conditional expectation of the entire estimator is tractable. | Analyze covariance before replacing one component. |
| B06 → H02 | Aggregation merges outcomes relevant to a claim. | Prove sufficiency for the restricted claim. |
| B06 → H04 | A reduced objective might achieve its infimum only at a boundary. | State only the exact aggregate identity. |
| C01 → E01 | A bound is intended as a trainable objective. | Report the bound without training claims. |
| C01 → E06 | Tightness is improved by more samples or latent flexibility. | First identify the actual gradient estimator. |
| C02 → D01 | The conjugate representation supplies a valid constrained/dual problem. | Check domains and interchange conditions. |
| C03 → C04 | Practical approximations replace the exact touching surrogate. | Keep the original conditional improvement statement. |
| C04 → C05 | A named error term admits a controlled local expansion. | Seek a nonlocal bound or counterexample. |
| C05 → C06 | The remainder is controlled in the proposed limiting regime. | Keep a local statement, not a scaling law. |
| C06 → H06 | A leading-order explanation is claimed beyond its regime. | Give the regime-specific prediction. |
| D01 → D02 | Functional stationarity is solvable on a valid probability domain. | Use numerical primal/dual optimization with residual checks. |
| D01 → D04 | The constraint/penalty is a Bregman divergence around the current iterate. | Keep the general constrained problem. |
| D02 → D03 | A coefficient is determined by a budget or marginal constraints. | Identify it as a free hyperparameter. |
| D02 → H03 | A population/distribution solution will be fitted from finite data. | Do not transfer it directly to neural parameters. |
| D03 → C04 | The constraint moment is approximated or solved inexactly. | Record the exact residual if computable. |
| D04 → D05 | A local quadratic metric is justified for the intended step. | Solve the original proximal problem or bound expansion error. |
| D05 → D06 | Applying/inverting the metric dominates cost. | Keep the full operator as a reference. |
| D06 → H05 | A factored metric changes the update directions. | Restrict claims to operator approximation/cost. |
| E01 → E02 | A differentiable sampling transform is available. | Use a valid score estimator or E05 for discrete variables. |
| E01 → E06 | The full derivative identifies the estimator whose signal/cost matters. | Derive missing gradient terms first. |
| E01 → B05 | Conditioning can expose nuisance randomness or causal cancellation. | Keep the full score/direct derivative. |
| E02 → E03 | A term has known expectation under the actual sampling law. | Derive its expectation before removing it. |
| E02 → E05 | Discreteness blocks ordinary pathwise derivatives. | Use the existing valid estimator. |
| E03 → E06 | Covariance and evaluation cost determine practical benefit. | Measure/derive those quantities; zero mean is insufficient. |
| E04 → E06 | Conditional estimation is feasible at a changed cost. | Compare the total computation, not variance alone. |
| E05 → E03 | Conditional relaxation and correction terms give a zero-mean control variate. | Label the result a biased relaxation. |
| E06 → B03 | Sampling allocation is adjustable and support can be maintained. | Adjust batching or the estimator itself. |
| E06 → C05 | Moment/SNR dependence can be expanded in a controlled sample-count regime. | Keep finite-sample measurements or nonasymptotic bounds. |
| F01 → F02 | The selected kernel has usable finite features. | Account for approximation error before reordering. |
| F02 → F03 | Causality permits an additive prefix sufficient statistic. | Use block computation or retain necessary history. |
| F03 → F04 | State updates are ordered identity-plus-low-rank products. | Preserve the recurrence without a fictitious prefix-sum shortcut. |
| F04 → C04 | The algebra is deployed in finite precision or bounded blocks. | Keep the exact algebraic statement separate. |
| F05 → G03 | Coupled iteration stability is consequential. | Do not claim global convergence from decreasing one block. |
| F06 → D06 | The reduced operator is still too expensive. | Solve it directly and audit residuals. |
| G01 → G02 | A root is available and its Jacobian is locally nonsingular. | Analyze degeneracy, regularize with a changed problem, or unroll. |
| G01 → G03 | A proposed solver uses repeated fixed-point iteration. | Use another root solver without assuming contraction. |
| G02 → C04 | Forward/backward solves are inexact. | Record exact local derivative conditions. |
| G04 → G05 | A monotone time variable simplifies the residual integral. | Approximate in the original coordinate. |
| G05 → C05 | Residual derivatives support a controlled quadrature expansion. | Use lower-order/adaptive integration with a justified error check. |
| G05 → G06 | The target can be a trajectory endpoint map instead of a solver step. | Keep the numerical-solver formulation. |
| G06 → H02 | Constancy along trajectories leaves multiple admissible maps. | Verify the boundary already identifies the desired endpoint. |
| G06 → H05 | Training uses detached or moving targets. | Differentiate the actual coupled objective. |
| H01 → H02 | Symmetries create observationally indistinguishable solutions. | Do not interpret harmless parameter redundancy as task ambiguity. |
| H02 → B06 | A reduced claim only needs identifiable aggregate quantities. | Add information/constraints, or state an impossibility boundary. |
| H03 → H02 | Empirical coverage removes distinctions used by the population proof. | Quantify ordinary estimation error at C04. |
| H03 → H04 | Empirical fitting can send probabilities to the boundary. | Check finite optimum and parameter-space restrictions. |
| H04 → D01 | A derived regularizer/constraint can control the offending divergence. | Accept nonattainment or change the claim. |
| H05 → E01 | The claimed objective and implemented update disagree. | State and analyze the update as its own field. |
| H06 → C04 | A counterexample isolates a missing error or approximation term. | Reject the universal claim; investigate its restricted validity. |
| D02 → B01 | Inverting the optimum relation exposes an eliminable latent reward or energy. | Keep the normalized distributional solution. |
| H01 → H03 | An invariant population reduction will be fitted from empirical comparisons. | Keep the result at the population level. |
| B01 → H03 | A decomposition was derived for a population expectation. | Identify the finite-sample objective directly. |
| H02 → H05 | An identifying boundary/constraint is implemented with a custom or detached update. | Analyze the ordinary constrained objective. |
| C04 → A05 | A missing scale/statistics term is a candidate explanation of the discrepancy. | Investigate another identified term. |
| C04 → D05 | Directional curvature, rather than scalar magnitude, is the unresolved term. | Avoid imposing a geometric explanation. |
| A05 → H05 | Batch statistics, clipping or detachment enter the normalization update. | Use the full transformed derivative. |

## Operations that do not freely commute

- **Differentiate ↔ detach:** `grad(wL)` and `stopgrad(w) grad(L)` differ by
  `L grad(w)` unless a valid identity cancels its expectation in the stated setup.
- **Expectation ↔ ratio/normalization:** `E[A/B]` is generally not `E[A]/E[B]`.
- **Approximate ↔ optimize:** an accurate objective approximation need not
  preserve minimizers, especially with flat directions or boundary optima.
- **Change coordinates ↔ take an optimizer step:** Euclidean steps depend on
  coordinates; show the transformed metric/update.
- **Discretize ↔ differentiate:** gradients of a numerical solve and of an exact
  continuous solution can differ; control both approximation and sensitivity.
- **Marginalize ↔ delete terms:** Rao–Blackwellize the full estimator or retain
  covariance accounting. Analytic evaluation of one term is not automatically
  a variance reduction of the sum.
- **Coarse-grain ↔ identify:** aggregation can preserve a desired marginal while
  making within-group behavior unknowable from the reduced objective.

## Closing a path

Every candidate links its selected operations to an actual derivation, what the
construction changes (objective / measure / estimator / geometry / computation),
at least one distinguishing prediction, an executable construction, and a
falsifier or applicable boundary. Shared algebra can be reused across a batch;
the candidate-specific construction and prediction cannot be replaced by a
shared generic paragraph. Parameter settings of one construction are not new ideas.

Validation should separate the closest explanations: objective reweighting vs
learning-rate effects; lower variance vs biased estimation; a new kernel vs a
faster evaluation; an exact distribution optimum vs a finite-data update.
Minimal confounding is a property of the comparison, not a limit on the number
of method stages, benchmark coverage, sample size or repetitions.
