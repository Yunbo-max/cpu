# A compact inquiry record

Use the parts needed for the question; do not require the user to fill a form.
Add these fields directly to the current research-autopilot idea or method
record; preserve one project state and one research workflow.
For every substantive method construction, its formal object, consequential derivation,
assumptions, distinctive prediction and falsifier are required. The agent completes
this analysis; it is not a new intake questionnaire or a promise of future work.

## Entry and reuse

Use [inquiry-generation.md](inquiry-generation.md) before locking in the object.
An empirical lead may have an unexplained observation and a controlled probe; do
not fabricate a proof to admit it. A hypothesis identifies a conditional account.
Only a method construction requires the complete consequential chain below.
Short identities and long branching proofs are both valid work products. One
active expensive method may contain multiple rival accounts. Reuse accepted
prefixes for fixes/seeds; object, assumption and update changes require affected
revalidation, not blind replay of everything. This is not an all-48 checklist.

## Record

1. **Question and evidence.** What needs explaining? Which successes, failures
   or reported observations are known? Which uncertainty matters?
2. **Formal object and assumptions.** Objective, distribution, estimator and
   update where relevant; support, scale, geometry and available information.
3. **Consequential derivation.** The selected mathematical move, important
   steps and resulting identity/bound/approximation/counterexample.
   Link the actual operation path and justify its transitions. State what changes
   in the objective, sampling law, estimator, geometry or computation; distinguish
   exact transformations from approximations and unsupported conjectures.
   For long or branching derivations, retain a resumable trace of formal
   intermediate results, applied operations, assumptions/errors, justified
   branch/merge/backtrack decisions and the unresolved frontier. Reuse valid
   prefixes. Trace length has no fixed quota; candidate counts apply to distinct
   justified constructions, not operations or intermediate proof steps.
4. **Competing explanations and predictions.** What should change, stay
   invariant or stop working? What separates the nearest explanations?
5. **Evidence that would revise the account.** An explicit falsifier or
   assumption check, not just a performance target.
6. **Research decision.** A justified construction, next measurement, boundary
   claim, literature question or decision to discard the mechanism.
   For a method candidate give an executable rule or algorithm, the closest
   existing alternative and a comparison that can distinguish the explanations.
7. **Status.** What was proved, checked numerically, observed, reported or
   left unresolved? What is known about prior art?

An incomplete record can still contain a useful result. Missing empirical data
does not invalidate a correct conditional derivation. An unexplained measured
phenomenon does not need invented mathematics to become worth investigating.
An unresolved mathematical basis remains an investigation lead until analyzed;
do not present it as a completed research idea or fill a candidate quota with it.
The record is an agent-produced mathematical discovery card, not user homework.
For each substantive new method or revision, preserve a pinned mathematical_trace
and substantive mathematical review at the scope of the claimed result. Apply the
selected edition's candidate and review contract; this handoff adds no candidate
quota, no all-48 traversal and no legacy pre-code admission campaign. The explicit
Simple/Chat edition rules take precedence over inherited full-edition defaults.
Use [research-reasoning.md](research-reasoning.md) to bind the trace and the goal-level
selection to actual tasks. A raw math_verified flag is not evidence. Reuse valid
prefixes on resume; changed derivations invalidate affected reviews and downstream
bindings. Public equations, proof steps and experimental justifications are work
products, not a transcript of private internal model reasoning. Label a retrospective
reconstruction honestly rather than inventing a contemporaneous trajectory.
An empirical lead can become a candidate through relevant mathematical analysis;
a mathematical construction can become a candidate before experiments, provided
its predictions and empirical status are explicit. Neither entry has precedence.

## Use within the research workflow

- At idea generation / H01, allow entry from observations, mathematical structure,
  literature tensions or their combination. Return linked explanations.
- At H03, sharpen the central claim and a prediction that distinguishes it from
  a simpler account. A baseline-gap measurement is one source of evidence.
- At M02, compare the intended objective with the estimator and actual update.
  Mathematical analysis can create a method, expose an equivalence or stop an
  invalid direction; it is not only a final notation check.
- At empirical execution, the existing orchestrator owns benchmark validation,
  budgets, reproducibility, baseline quality and the project decision.
- Re-enter analysis after a success, null result or failure that changes the
  explanation. Do not treat theory as a one-time pre-experiment stage.

This internal procedure is required for all idea-generation routes, including
empirical, composition, efficiency and reframe routes. Apply it to every candidate
and substantive revision using the bundled mathematical references. It has no
independent installation or invocation; missing mathematical evidence remains a
named investigation within the same research workflow.

## Signs the process has become superficial

| Symptom | Correction |
|---|---|
| A failure census followed by an attractive module | Derive the suspected cause and compare another explanation. |
| A long list of named mathematical tools | Select a tool and carry out its consequential steps. |
| A scale change called a new objective without checking invariance | Compare the transformed objective and actual optimizer. |
| A bound quoted without equality conditions or scale | Check tightness in the relevant regime. |
| A theorem that cannot change any observation or decision | State its operational implication or narrow the contribution. |
| An experiment only asking whether the method wins | Add a comparison that distinguishes the proposed mechanism. |
| Every contradictory result explained away | Record and act on a falsifier. |
| A toy algebra example presented as empirical effectiveness | Label it as an identity or counterexample check. |
