# Primary-paper atlas for mathematical discovery

Read and verified on 2026-10-05. This is a purposive, cross-topic sample of
20 ICML/NeurIPS papers, not an exhaustive survey or a ranking. Reading covered
the method sections and central derivations identified below, with selected
theorem assumptions; it did not reproduce every proof, inspect every codebase,
or replicate the experiments. Conference PDFs are used unless an author version
is explicitly identified. Section/equation references belong to that version.

The reusable paths are our reconstruction of dependencies, not an account of
how the authors personally discovered their ideas. Check the original source
again when a candidate depends on a technical detail or later revision.

## S01 — Trust Region Policy Optimization · ICML 2015

[Paper and proceedings](https://proceedings.mlr.press/v37/schulman15.html).
Read §§3–5, particularly the performance bound and its practical relaxation.
**Construction:** bound policy change, form an improvement surrogate, then
approximate a constrained update. **Boundary:** the theoretical worst-state
divergence control becomes average KL in the practical algorithm; the original
guarantee cannot be transferred unchanged. Discount, advantage bounds, sampling
and local approximation matter. **Reusable move:** track exactly where a
theory-backed objective becomes a computational approximation. Path P01/P07;
operations C03, D04, C04.

## S02 — Direct Preference Optimization: Your Language Model is Secretly a Reward Model · NeurIPS 2023

[Conference paper](https://proceedings.neurips.cc/paper_files/paper/2023/hash/a85b405ed65c6477a4fe8302b5e06ce7-Abstract-Conference.html).
Read §4, Eqs. 4–7 and the reward/policy reparameterization.
**Construction:** solve a KL-regularized reward problem, invert the normalized
policy relation, and substitute into a same-prompt preference likelihood.
**Boundary:** cancellation of the prompt-specific partition term depends on the
comparison structure. Reference support and preference-model assumptions remain;
objective/optimum relationships do not imply identical training trajectories.
**Reusable move:** eliminate an inaccessible object through a valid invariant.
Path P02; operations D02, B01, B02, H01.

## S03 — Sinkhorn Distances: Lightspeed Computation of Optimal Transport · NeurIPS 2013

[Conference paper](https://proceedings.neurips.cc/paper_files/paper/2013/hash/af21d0c97db2e27e13572cbf59eb343d-Abstract.html).
Read §§2–4, entropy regularization, matrix scaling and Lemma 2.
**Construction:** regularize transport, use stationarity to express its matrix
as diagonal scalings of an exponential cost kernel, then enforce marginals by
iterative scaling. **Boundary:** positivity/feasibility and regularization affect
conditioning and approximation to unregularized transport. Large inverse
regularization can make numerical computation difficult. Do not identify all
regularized costs with an ordinary metric. **Reusable move:** a constraint plus
factor structure determines an algorithm. P01; D01, D02, F05.

## S04 — Tighter Variational Bounds are Not Necessarily Better · ICML 2018

[Proceedings and PDF](https://proceedings.mlr.press/v80/rainforth18b.html).
Read §3/Theorem 1, the SNR derivation and §4's empirical checks.
**Construction:** examine gradient means and variances separately as importance
sample count increases; generative and inference parameters have different
asymptotic behavior. **Boundary:** the standard estimator, moment assumptions,
nondegenerate leading terms and the asymptotic regime matter. Directional
accuracy and total compute also matter; the paper does not prove that every
tighter bound is harmful. **Reusable move:** objective quality and estimator
quality require separate analysis. P03; C01, E06, C05, C06.

## S05 — Sticking the Landing: Simple, Lower-Variance Gradient Estimators for Variational Inference · NeurIPS 2017

[Conference paper](https://proceedings.neurips.cc/paper/2017/hash/e91068fff3d7fa1594dfdf3b4308433a-Abstract.html).
Read §§2–3 and the path-derivative/score decomposition, including the discussion
of analytically evaluated KL terms. **Construction:** remove a zero-mean score
contribution to obtain a path estimator with useful behavior near the true
posterior. **Boundary:** unbiasedness needs the appropriate law/regularity;
covariance prevents a blanket claim that deleting any zero-mean term always
reduces variance. Analytically evaluating one addend is not Rao–Blackwellization
of the entire estimator. **Reusable move:** look for cancellation before
simplifying a stochastic expression. P04; E02, E03, B05.

## S06 — REBAR: Low-variance, unbiased gradient estimates for discrete latent variable models · NeurIPS 2017

[Conference paper](https://papers.nips.cc/paper_files/paper/2017/hash/ebd6d2f5d60ff9afaeda1a81fc53e2d0-Abstract.html).
Read §§2.2–3.2, especially the estimator in Eq. 4.
**Construction:** combine a continuous relaxation, a conditional relaxation and
score/pathwise correction terms into a control-variate estimator.
**Boundary:** the correction preserves unbiasedness; the relaxed pathwise term
alone does not. Coupling, coefficients and temperature affect variance.
**Reusable move:** introduce an easy biased object, then derive exactly what
must be added/subtracted to recover the desired expectation. P04; E05, E03, E06.

## S07 — Optimizing Neural Networks with Kronecker-factored Approximate Curvature · ICML 2015

[Proceedings and PDF](https://proceedings.mlr.press/v37/martens15.html).
Read §2 and the Fisher-block factorization.
**Construction:** exploit outer-product layer gradients, then approximate
expectations of Kronecker products by products of moments to obtain tractable
curvature operations. **Boundary:** the moment factorization is an approximation,
not an algebraic identity. Damping and the distinction between Fisher and other
curvature matrices matter. **Reusable move:** derive the expensive operator
first, then identify the approximation that makes it usable. P07; D05, D06.

## S08 — Shampoo: Preconditioned Stochastic Tensor Optimization · ICML 2018

[Proceedings and PDF](https://proceedings.mlr.press/v80/gupta18a.html).
Read Algorithm 1, tensor/matrix construction and the online mirror-descent
analysis setup. **Construction:** accumulate smaller mode-wise second-moment
matrices and use matrix powers to precondition tensor updates.
**Boundary:** this retains directional information at different cost from a full
flattened metric; matrix roots and regularization are substantive. Online convex
regret guarantees do not establish global convergence in deep nonconvex models.
**Reusable move:** connect representation shape, metric structure and a feasible
update. P07; D04, D06.

## S09 — How Does Batch Normalization Help Optimization? · NeurIPS 2018

[Conference paper](https://papers.nips.cc/paper_files/paper/2018/hash/905056c1ac1dad141560467e0a99e1cf-Abstract.html).
Read the mechanism interventions in §§2–3 and §4's single-layer analysis,
including Theorem 4.1. **Construction:** challenge one proposed explanation,
then analyze changes in gradients and local smoothness under normalization.
**Boundary:** the theoretical comparison has a specified layer/setup and
normalization scales; it is not a universal guarantee that normalization
improves every network or a complete explanation of BatchNorm.
**Reusable move:** an empirical counterexample can redirect the mathematical
object being analyzed. P14; H06, A05, D05.

## S10 — Random Features for Large-Scale Kernel Machines · NeurIPS 2007

[Conference paper](https://papers.nips.cc/paper_files/paper/2007/hash/013a006f03dbc5392effeb8f18fda755-Abstract.html).
Read §3's Fourier-feature construction and approximation argument.
**Construction:** represent an eligible shift-invariant kernel as a spectral
expectation, then approximate it with sampled features.
**Boundary:** Bochner's conditions and the kernel normalization matter; finite
features approximate the kernel rather than reproduce it exactly. Approximation
error and downstream optimization are distinct.
**Reusable move:** a representation theorem exposes a computational estimator.
P08; F01, C04.

## S11 — Transformers are RNNs: Fast Autoregressive Transformers with Linear Attention · ICML 2020

[Proceedings and PDF](https://proceedings.mlr.press/v119/katharopoulos20a.html).
Read §3, the reassociated attention expression and autoregressive recurrence.
**Construction:** factor a chosen similarity, reorder contractions, and retain
prefix statistics plus the normalizer.
**Boundary:** replacing softmax similarity with another kernel changes the model;
reordering the chosen factorized expression is the exact step. Complexity depends
on feature dimension, masking and stored state.
**Reusable move:** separate representation choice from algebraic acceleration.
P08; F01, F02, F03.

## S12 — Deep Equilibrium Models · NeurIPS 2019

[Conference paper](https://papers.nips.cc/paper/2019/hash/01386bd6d8e091c2ab4c7c7de644d37b-Abstract.html).
Read §§3.1.1–3.1.3 and Theorem 1's implicit-gradient expression.
**Construction:** replace an unrolled repeated transformation with a root solve,
then differentiate its defining equation using a linear system.
**Boundary:** local differentiability and a nonsingular Jacobian are required;
root existence, iteration convergence and solver accuracy are separate issues.
Memory independent of unrolled depth does not imply constant computation.
**Reusable move:** differentiate a solution's equation instead of its entire
construction history. P10; G01, G02, C04.

## S13 — Denoising Diffusion Probabilistic Models · NeurIPS 2020

[Conference paper](https://proceedings.neurips.cc/paper_files/paper/2020/hash/4c5bcfec8584af0d967f1ab10179ca4b-Abstract.html).
Read §§2–3, particularly Eqs. 8, 12 and 14.
**Construction:** decompose a variational objective into Gaussian terms and
reparameterize reverse means as noise prediction.
**Boundary:** the resulting weighted MSE is an algebraic rewrite under the stated
variance choices; the simplified unweighted training loss changes timestep
weighting. These are two distinct steps.
**Reusable move:** carry induced weights through a variable substitution before
deciding which weights to change. P05; C01, A06, A03.

## S14 — Improved Denoising Diffusion Probabilistic Models · ICML 2021

[Proceedings and PDF](https://proceedings.mlr.press/v139/nichol21a.html).
Read §3, especially §3.3/Eq. 17 and the hybrid-loss gradient treatment.
**Construction:** sample loss terms using estimated second moments and compensate
with inverse sampling probability to reduce objective-estimation noise.
**Boundary:** histories estimate changing moments; preserving the expected loss
requires support and correction weights. The paper's loss-second-moment proposal
is not automatically the optimum for parameter-gradient variance.
**Reusable move:** modify the estimator separately from the objective.
P06; B03, E06, A04.

## S15 — Elucidating the Design Space of Diffusion-Based Generative Models · NeurIPS 2022

[Conference paper](https://papers.nips.cc/paper/2022/hash/a98846e9d9cc01cfb87eb694d946ce6b-Abstract-Conference.html).
Read the common formulation, Table 1 and §5/Eqs. 7–8.
**Construction:** express a denoiser through input/output scaling and a skip
connection, derive its effective target and weight, and disentangle design axes.
**Boundary:** variance-based preconditioning choices and empirically chosen
conditioning/sampling choices have different evidential status. A bundled gain
does not identify which choice caused it.
**Reusable move:** rewrite the actual network's training problem, not only its
external prediction formula. P05; A01, A05, A06, A03.

## S16 — DPM-Solver: A Fast ODE Solver for Diffusion Probabilistic Model Sampling in Around 10 Steps · NeurIPS 2022

[Conference PDF](https://papers.nips.cc/paper_files/paper/2022/file/260a14acce2a89dad36adc8eefe7c59e-Paper-Conference.pdf).
Read §3, Proposition 3.1 and Theorem 3.2's stated regularity dependency.
**Construction:** integrate the known linear part exactly, change to half-log-SNR
time, and approximate the remaining weighted integral.
**Boundary:** the order result depends on smoothness and step size in the new
coordinate; it is not a distribution-quality guarantee for arbitrary large steps.
**Reusable move:** exploit operator structure before selecting an approximation.
P11; G04, G05, C05.

## S17 — Consistency Models · ICML 2023

[Proceedings and PDF](https://proceedings.mlr.press/v202/song23a.html).
Read §§3–4, boundary parameterization, Definition 1 and Algorithms 2–3.
**Construction:** learn a trajectory-invariant endpoint map with a boundary
condition, using local consistency pairs and moving targets.
**Boundary:** anchoring is essential; numerical pair construction, score error
and detached targets introduce distinct assumptions. Local empirical agreement
alone is not proof of a correct global map.
**Reusable move:** identify what a computation conserves and learn the desired
invariant subject to an identifying boundary. P12; G06, H02, H05.

## S18 — Parallelizing Linear Transformers with the Delta Rule over Sequence Length · NeurIPS 2024

[Conference PDF](https://proceedings.neurips.cc/paper_files/paper/2024/file/d13a3eae72366e61dfdc7eea82eeb685-Paper-Conference.pdf).
Read §3's delta recurrence and compact product construction, plus the
chunk-computation pseudocode in Appendix D.
**Construction:** expose ordered rank-one update factors and reorganize their
product for block computation.
**Boundary:** product order matters; generalized Householder factors are not
automatically orthogonal. A recurrence-preserving implementation claim needs
numerical and hardware validation separately from model-quality claims.
**Reusable move:** a sequential-looking algorithm may have exploitable matrix
algebra. P09; F03, F04.

## S19 — Proximalized Preference Optimization for Diverse Feedback Types: A Decomposed Perspective on DPO · NeurIPS 2025

[Author version v2](https://arxiv.org/html/2505.23316v2);
[official NeurIPS 2025 proceedings index](https://papers.nips.cc/paper_files/paper/2025/vol38-main-conference).
Read §§3–4, Theorems 3.1–3.2 and 4.1–4.2. **Construction:** decompose population
DPO, inspect what empirical restriction loses, aggregate unobserved response
mass, and analyze boundary behavior of the new objective.
**Boundary:** theorem assumptions include positive coverage and, for several
claims, existence of an optimum; distribution-space results need not transfer
unchanged to a neural family. Coarse-graining controls aggregate mass without
identifying every internal probability. **Reusable move:** use population/empirical
mismatch to discover a tractable missing constraint. P13; H03, B06, H04.

## S20 — QUATRO: Query-Adaptive Trust Region Policy Optimization for LLM Fine-tuning · ICML 2026

[Official proceedings](https://proceedings.mlr.press/v306/lee26au.html);
[author version v2 read](https://arxiv.org/html/2602.04620v2).
Read §3, the prompt-wise dual problem and Eqs. 14–19 with gradient detachment.
**Construction:** derive a per-prompt distributional trust-region solution and
calibrate a dual coefficient, then build a parameterized training update.
**Boundary:** distinguish exact population optimization from finite rollouts,
projection and multiple optimizer steps. Inspect detached fields explicitly;
the word “exact” does not certify every sampled update's KL feasibility. Reward
variance alone does not order dual coefficients for arbitrary reward laws.
**Reusable move:** trace a budget through normalization, dual solution and actual
code-level derivatives. P01; D01–D03, H03, H05.

## Extending this atlas

Add papers because they supply a different mathematical operation, dependency,
failure condition or counterexample. Record the primary URL, venue/version,
sections actually read, consequential equations, and an applicability boundary.
Prefer several deep examples over an unexamined citation list. Do not label a
preprint as ICML/NeurIPS without verifying the venue. The earlier OPD/TOP-D
examples in math-worked-examples.md remain separate examples; they are not counted
as additional conference papers in this sample.
