from restore_subset import ROOT, SplitReader, digest
import json, pathlib, zipfile, hashlib
items=json.loads((ROOT/'restore-additional-core.json').read_text())
groups={}
for item in items:groups.setdefault(item['pack'],[]).append(item)
receipts=[]
for pack, selected in groups.items():
    reader=SplitReader(pack)
    with zipfile.ZipFile(reader) as archive:
        for item in selected:
            relative=pathlib.PurePosixPath(item['path']).relative_to('windows/W0004')
            assert '..' not in relative.parts
            target=ROOT/'candidate'/relative;target.parent.mkdir(parents=True,exist_ok=True)
            if target.exists():assert digest(target)==item['sha256'];continue
            h=hashlib.sha256();n=0
            with archive.open(item['member']) as src,target.open('xb') as dst:
                while b:=src.read(1048576):dst.write(b);h.update(b);n+=len(b)
            assert h.hexdigest()==item['sha256'] and n==item['bytes'],item['path']
            target.chmod(item['mode']);receipts.append({'path':str(relative),'sha256':h.hexdigest(),'bytes':n})
    print(json.dumps({'pack':pack,'selected_members':len(selected),'verified_parts':len(reader.verified)}),flush=True)
(ROOT/'additional-restore-receipt.json').write_text(json.dumps({'members':receipts,'scope':'Selected members/touched parts; not all history re-downloaded'},indent=2)+'\n')
