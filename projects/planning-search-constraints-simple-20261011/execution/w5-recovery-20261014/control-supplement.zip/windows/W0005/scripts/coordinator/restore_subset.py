import hashlib, io, json, pathlib, urllib.request, zipfile, time

ROOT = pathlib.Path(__file__).resolve().parent
BASE = 'https://raw.githubusercontent.com/Yunbo-max/cpu/989b9182460a173fa4fa924d853572e41a880ce2/'

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()

def download(path, destination, expected=None):
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and (expected is None or digest(destination)==expected): return
    for attempt in range(3):
        try:
            with urllib.request.urlopen(BASE+path, timeout=60) as source, destination.with_suffix('.partial').open('wb') as output:
                while data:=source.read(1048576):output.write(data)
            if expected: assert digest(destination.with_suffix('.partial'))==expected,path
            destination.with_suffix('.partial').replace(destination)
            return
        except Exception:
            if attempt==2:raise

class SplitReader(io.RawIOBase):
    def __init__(self, pack):
        self.pack=pack;self.cache=ROOT/'parts'/pathlib.Path(pack).name
        index=self.cache/'index.json';download(pack+'/index.json',index)
        self.index=json.loads(index.read_text());self.position=0;self.verified=set()
    def readable(self):return True
    def seekable(self):return True
    def tell(self):return self.position
    def seek(self, offset, whence=0):
        self.position=offset if whence==0 else self.position+offset if whence==1 else self.index['bytes']+offset
        if self.position<0:raise ValueError('negative seek')
        return self.position
    def read(self, size=-1):
        size=min(size if size>=0 else self.index['bytes'],self.index['bytes']-self.position)
        result=bytearray()
        while size>0:
            i=self.position//self.index['part_size'];offset=self.position%self.index['part_size'];part=self.index['parts'][i]
            local=self.cache/part['path'];download(self.pack+'/'+part['path'],local,part['sha256']);self.verified.add(part['path'])
            take=min(size,part['bytes']-offset)
            with local.open('rb') as f:f.seek(offset);data=f.read(take)
            assert len(data)==take
            result.extend(data);size-=take;self.position+=take
        return bytes(result)

if __name__=='__main__':
    manifest=json.loads((ROOT/'core68-manifest.json').read_text())
    assert digest(ROOT/'core68-manifest.json')=='af0708304697337f7c36b1cac238167fa2522bee75a4aad5df12b909484b328f'
    wanted=json.loads((ROOT/'restore-needed-core.json').read_text())
    groups={}
    for item in wanted:groups.setdefault(item['pack'],[]).append(item)
    receipts=[]
    for pack,items in groups.items():
        remote=SplitReader(pack)
        with zipfile.ZipFile(remote) as archive:
            for item in items:
                relative=pathlib.PurePosixPath(item['path']).relative_to('windows/W0004')
                assert '..' not in relative.parts
                target=ROOT/'candidate'/relative;target.parent.mkdir(parents=True,exist_ok=True)
                h=hashlib.sha256();size=0
                with archive.open(item['member']) as source,target.open('xb') as output:
                    while data:=source.read(1048576):output.write(data);h.update(data);size+=len(data)
                assert size==item['bytes'] and h.hexdigest()==item['sha256'],item['path']
                target.chmod(item['mode'])
                receipts.append({'path':str(relative),'bytes':size,'sha256':h.hexdigest(),'pack':pack})
        print(json.dumps({'pack':pack,'selected_members':len(items),'verified_parts':len(remote.verified)}),flush=True)
    (ROOT/'selected-restore-receipt.json').write_text(json.dumps({'members':receipts,'scope':'Selected member and touched part hashes only; not a new complete archive verification'},indent=2)+'\n')
