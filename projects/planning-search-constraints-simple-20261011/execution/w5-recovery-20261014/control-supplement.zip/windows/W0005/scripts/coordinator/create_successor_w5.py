"""Create a linked finite successor using unchanged Simple13 public APIs.

Never loads or writes the corrupt predecessor as a live controller. Historical
journal events are replayed as records, not as command submissions or experiments.
"""
import datetime, hashlib, json, math, pathlib, shutil, sqlite3, sys, time
import zstandard

BASE=pathlib.Path(__file__).resolve().parent
SOURCE=BASE/'rsi-simple-13'
sys.path.insert(0,str(SOURCE/'scripts'))
from simple_loop import SimpleLoop
from simple_runner import SimpleRunner
from _simple_source import current_source_identity

def sha(p):
    h=hashlib.sha256()
    with pathlib.Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()

def write(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,indent=2,sort_keys=True,allow_nan=False)+'\n')

def main():
    validation=json.loads((BASE/'predecessor-69-validation.json').read_text())
    assert validation['all_terminal'] and validation['attempts']==69
    assert validation['contract_and_receipt_inline_sha_matches']==138
    assert validation['matched_core68_manifest']==136
    direct=json.loads((BASE/'direct-receipts-verification.json').read_text())
    assert {x['sha256'] for x in validation['not_in_core68']} <= {x['sha256'] for x in direct}
    assert validation['budget']['reserved_seconds']==0
    assert time.time()>validation['budget']['deadline_epoch']
    assert current_source_identity(SOURCE)['digest']==validation['source']=='0022b214e957337ba9035f77ed7036cfaa51d11cb467ac0d6b99df5b0fa96336'
    with (BASE/'accepted-v3-complete-stdout.json.zst').open('rb') as f,zstandard.ZstdDecompressor().stream_reader(f) as z:old=json.load(z)
    selected=next(t for t in old['tasks'] if t['task_id']=='R005L2-depots-p05-states_ops-600s-3000M-host-v3')
    candidate=BASE/'candidate';root=BASE/'project/windows/W0005'
    if not root.exists():
        assert candidate.is_dir()
        for ref in selected['input_refs']:assert sha(candidate/ref['path'])==ref['sha256'],ref['path']
        root.parent.mkdir(parents=True,exist_ok=True);candidate.rename(root)
    else:
        for ref in selected['input_refs']:assert sha(root/ref['path'])==ref['sha256'],ref['path']
    # Keep the complete verified prior export, all physical contracts/receipts,
    # source identity, immutable archive pointers, and original event timestamps.
    history=root/'history/W0004';history.mkdir(parents=True,exist_ok=True)
    for name in ['accepted-v3-complete-stdout.json.zst','predecessor-69-validation.json','direct-receipts-verification.json','forensic-manifest.json','source-identity.json']:
        if not (history/name).exists():shutil.copyfile(BASE/name,history/name)
    write(history/'original-journal-history.json',old['journal']['history'])
    write(history/'native-ledger.json',{'attempts':old['attempts'],'budget':old['budget'],'queued_tasks':[t for t in old['tasks'] if t['state']=='queued'],'scope':'Historical W4 records only; no queued predecessor is executable in W5'})
    predecessor_current=json.loads((BASE/'current.json').read_text())
    floor=predecessor_current['project_ledger']
    successor={
        'schema':1,'window':'W0005','predecessor':'W0004','same_project':True,'same_idea':'constraint-propagation-cost-v1',
        'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'reason':'Actual predecessor finite deadline reached; user authorized continued same-project work and requested retry. Corrupt predecessor retained, not repaired or overwritten.',
        'predecessor_deadline_epoch':validation['budget']['deadline_epoch'],'predecessor_native_attempts':69,
        'prior_attempts_lower_bound':floor['combined_attempt_floor'],'prior_command_seconds_lower_bound':floor['combined_command_seconds_floor'],
        'prior_scoped_research_cycles':old['research_cycle_count'],'source_digest':validation['source'],
        'old_user_stops_retained':True,'old_SQLite_untouched':True,'old_deadline_unchanged':True,
        'predecessor_active_or_unknown':0,'predecessor_reservation_seconds':0,
        'last_accepted_decision':old['journal']['current_research_review'],
        'predecessor_export':{'path':'history/W0004/accepted-v3-complete-stdout.json.zst','sha256':sha(history/'accepted-v3-complete-stdout.json.zst')},
        'predecessor_archive_commit':'989b9182460a173fa4fa924d853572e41a880ce2',
        'accounting_scope':'Window command counters start locally at0 while the project lower floor283/15590.955507759041 and all scientific events/history persist; not independent samples or a fresh total research budget. Historical journal replay is maintenance, not new experiments/cycles.',
        'host_policy':'Kernel memory.max only; no project/shared/cache prelaunch gates. Frozen native experiment CPU/AS/RSS/wall limits remain unchanged.',
        'restart_constraint':'Only this finite W5 queue is current. Never restart W4 or submit completed R005/R005L1/R006/R007 tasks.'}
    assert successor['prior_attempts_lower_bound']==283
    assert math.isclose(successor['prior_command_seconds_lower_bound'],15590.955507759041,abs_tol=1e-7)
    link=root/'W5_SUCCESSOR.json'
    if not link.exists():write(link,successor)
    else:assert json.loads(link.read_text())['prior_attempts_lower_bound']==283
    loop=SimpleLoop(root)
    loop.initialize(old['journal']['active_idea'],old['goal'],max_iterations=old['journal']['limits']['max_iterations'],max_repairs=old['journal']['limits']['max_repairs'])
    replayed=[]
    for item in old['journal']['history'][1:]:
        actual=loop.record(item['event'],item['version']-1)
        replayed.append({'version':item['version'],'original_created_at':item['created_at'],'event_id':item['event']['event_id']})
    restored=loop.status();expected=old['journal'].copy()
    # Actual replay timestamps and the new physical root differ by design; all
    # scientific state, history events, usage, review ancestry and cycles must match.
    def view(x):
        y=dict(x);y.pop('root',None);y['history']=[{k:v for k,v in e.items() if k!='created_at'} for e in y['history']];return y
    assert view(restored)==view(expected),'Public scientific journal mismatch; do not dispatch'
    config={'idea':old['journal']['active_idea'],'goal':old['goal'],'goal_contract':old['goal_contract'],
            'limits':{'max_attempts':500,'max_command_seconds':80000,'deadline_seconds':86400,'max_concurrency':1}}
    write(root/'plans/W5_runner_config.json',config)
    runner=SimpleRunner(root);status=runner.initialize(config)
    assert status['budget']['attempts_used']==0 and status['budget']['reserved_seconds']==0
    assert status['source']['digest']==validation['source']
    database=root/'.research-autopilot/simple-loop.sqlite3'
    with sqlite3.connect(database.as_uri()+'?mode=ro',uri=True) as connection:
        integrity=connection.execute('PRAGMA integrity_check').fetchall()
    assert integrity==[('ok',)]
    proof={'schema':1,'public_API_only':True,'predecessor_SQLite_written':False,'scientific_journal_equal_excluding_root_and_replay_timestamps':True,
           'replayed_original_events':len(replayed),'inherited_scoped_research_cycles':restored['research_cycles'].__len__(),
           'original_event_timestamps_retained_in':'history/W0004/original-journal-history.json',
           'historical_replay_is_not_new_scientific_execution':True,'source_digest':status['source']['digest'],'window_budget':status['budget'],
           'project_prior_floor':{'attempts':283,'command_seconds':15590.955507759041},'integrity_check':'ok','native_attempts_dispatched':0,'root':str(root)}
    write(root/'evidence/W5-journal-replay-and-initialization-proof.json',proof)
    print(json.dumps(proof))

if __name__=='__main__':main()
