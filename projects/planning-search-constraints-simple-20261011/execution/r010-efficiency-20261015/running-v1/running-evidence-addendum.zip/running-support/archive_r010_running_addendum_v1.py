"""Light post22 execution evidence while the sole finite coordinator continues; not full control."""
import pathlib,json,hashlib,zipfile,datetime,sys,shutil
B=pathlib.Path(__file__).resolve().parent/'planning-resume-20261014';R=B/'project/windows/W0005';O=B/'r010-running-publication';O.mkdir(exist_ok=False);sys.path.insert(0,str(B/'rsi-simple-13/scripts'));from simple_runner import SimpleRunner
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
r=SimpleRunner(R);s=r.status();health=r.health();attempts=[a for a in s['attempts'] if a['task_id'].startswith('R010-native-efficiency-p')];assert not s['stop_requested'];members={};archive=O/'running-evidence-addendum.zip';prior=json.loads((B/'r010-warmup-publication/manifest.json').read_text());index=dict(prior['members']);index.update({x['path']:x for x in prior['unchanged_source_aliases']});aliases=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 def add(p,n):
  data=p.read_bytes();z.writestr(n,data);members[n]={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'mode':p.stat().st_mode&0o777}
 for p in R.rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts:continue
  rel=str(p.relative_to(R));n='windows/W0005/'+rel
  selected=rel.startswith(('plans/R010-native-efficiency-','evidence/R010-native-efficiency-')) or rel.startswith('results/R010-native-efficiency-p')
  if not selected:continue
  h=sha(p)
  if n in index and index[n]['sha256']==h:aliases.append({'path':n,'bytes':p.stat().st_size,'sha256':h,'prior_manifest_commit':'607b95668e281d9b074788ad1c4eb7b078c52434','prior_manifest':'execution/r010-efficiency-20261015/warmups-v1/manifest.json','prior_path':n});continue
  add(p,n)
 for a in attempts:
  root=R/'.research-autopilot/runner/attempts'/a['attempt_id']
  for p in root.rglob('*'):
   if p.is_file():add(p,'windows/W0005/'+str(p.relative_to(R)))
 for p in [B/'recovery-20261015/r010-efficiency-coordinator-v1.log',B/'recovery-20261015/warmup-pointer-independent-readback-v2.json',B/'recovery-20261015/warmup-pointer-independent-readback-v2.log',pathlib.Path(__file__),pathlib.Path(__file__).parent/'verify_r010_pointer_metadata_v2.py']:
  add(p,'running-support/'+p.name)
m={'format':'light-post-control-evidence-addendum-v1','archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'members':members,'unchanged_aliases':aliases,'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'actual_budget_at_observation':s['budget'],'scored_attempts_at_observation':[{k:a.get(k) for k in ['attempt_id','task_id','state','result','receipt_ref']} for a in attempts],'accepted_decision_at_observation':s['journal']['current_research_review'],'health_at_observation':health,'sole_coordinator_owned_exec_session':25196,'consistent_control_base':{'packet_commit':'607b95668e281d9b074788ad1c4eb7b078c52434','manifest':'execution/r010-efficiency-20261015/warmups-v1/manifest.json','manifest_sha256':sha(B/'r010-warmup-publication/manifest.json'),'attempts':22,'remote_verified':True},'scope':'Light current source/selection/contract/receipt/log/native outputs only; live logs are captured prefixes. This is NOT a consistent new post22 SQLite/control snapshot or complete scored batch. Latest local actual status wins. Do not restore22 over active/unknown or resubmit existingIDs. Complete scored effect still pending; no speed claim.'};write(O/'manifest.json',m)
cur=json.loads((B/'r010-warmup-publication/CURRENT_EXECUTION.json').read_text());cur.update(updated_utc=m['observed_utc'],window_budget=s['budget'],actual_health=health,status_observed=s['status'],current_accepted_decision=s['journal']['current_research_review'],active_or_unknown_attempts=sum(a['state']!='terminal' for a in s['attempts']),archive_pointer='R010_EFFICIENCY_LATEST.json',running_addendum_scope='Light post22 evidence, NOT updated consistentSQLite; full control recovery pointer remains verified22. Ongoing finite coordinator is sole dispatchwriter; observe rather than duplicate.')
cur['project_ledger'].update(window_attempts=s['budget']['attempts_used'],window_command_seconds=s['budget']['elapsed_seconds'],combined_attempt_floor=283+s['budget']['attempts_used'],combined_command_seconds_floor=15590.955507759041+s['budget']['elapsed_seconds']);cur['R010_efficiency'].update(scored_completed=sum(a['state']=='terminal' and a.get('result')=='succeeded' for a in attempts),scored_effect='incomplete_frozen_batch_no_claim',coordinator_owned_exec_session=25196);cur['active_coordinator']={'single_queue':'W0005','owned_exec_session':35985,'finite_coordinator_owned_exec_session':25196,'observed_health':health,'active_or_unknown':[{k:a.get(k) for k in ['attempt_id','task_id','state']} for a in s['attempts'] if a['state']!='terminal']};write(O/'CURRENT_EXECUTION.json',cur)
prefix='projects/planning-search-constraints-simple-20261011/';folder=prefix+'execution/r010-efficiency-20261015/running-v1/';files=[(O/'manifest.json',folder+'manifest.json'),(archive,folder+archive.name),(O/'CURRENT_EXECUTION.json',prefix+'CURRENT_EXECUTION.json')];rows=[]
for p,n in files:
 raw=p.read_bytes();rows.append({'local':str(p),'path':n,'bytes':len(raw),'sha256':sha(p),'git_sha':hashlib.sha1(b'blob '+str(len(raw)).encode()+bytes([0])+raw).hexdigest()})
write(O/'uploads.json',rows);print(json.dumps({'files':len(rows),'bytes':archive.stat().st_size,'budget':s['budget'],'attempts':m['scored_attempts_at_observation']}))
