"""Bounded non-overwriting diagnostic for an observed truncated verification scratch copy."""
import pathlib,json,zipfile,hashlib,os,datetime
B=pathlib.Path(__file__).resolve().parent/'planning-resume-20261014';O=B/'r010-complete-compact-publication';D=O/'write-diagnostic-v1';D.mkdir(exist_ok=False);m=json.loads((O/'remote/manifest.json').read_text());x=m['derived_raw_objects'][4];rows=[]
with zipfile.ZipFile(O/'remote/remote.zip') as z:raw=z.read(x['encoded_member'])
def hs(q):return hashlib.sha256(q).hexdigest()
assert hs(raw)==x['encoded_sha256'] and len(raw)==x['encoded_bytes']
failed=O/'remote'/pathlib.Path(x['encoded_member']).name;rows.append({'kind':'retained_original_failed_output','bytes':failed.stat().st_size,'sha256':hs(failed.read_bytes()),'is_exact_prefix_of_verified_member':raw.startswith(failed.read_bytes())})
for mode in ['write_bytes','checked_chunks_fsync']:
 p=D/(mode+'.zst');assert not p.exists()
 if mode=='write_bytes':written=p.write_bytes(raw)
 else:
  written=0
  with p.open('xb') as f:
   for k in range(0,len(raw),65536):
    q=raw[k:k+65536];n=f.write(q);assert n==len(q);written+=n
   f.flush();os.fsync(f.fileno())
 rows.append({'kind':mode,'write_returned':written,'expected_bytes':len(raw),'immediate_bytes':p.stat().st_size,'immediate_sha256':hs(p.read_bytes()),'matches_expected':p.stat().st_size==len(raw) and hs(p.read_bytes())==x['encoded_sha256']})
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_member':x,'verified_remote_member_bytes':len(raw),'verified_remote_member_sha256':hs(raw),'observations':rows,'scope':'One bounded isolated write diagnostic; no inference to previous historical corruption or any native CPU/RAM failure. Original failed scratch output preserved.'}
with (D/'result.json').open('w') as f:print(json.dumps(result,indent=2),file=f)
print(json.dumps(result))
