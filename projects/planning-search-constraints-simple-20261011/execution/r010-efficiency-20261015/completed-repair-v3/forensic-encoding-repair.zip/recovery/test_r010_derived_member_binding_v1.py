"""Regression: a recovery map must bind the actual packaged encoding bytes."""
import pathlib,json,hashlib,zipfile,sys
B=pathlib.Path(__file__).resolve().parent/'planning-resume-20261014';mode=sys.argv[1];O=B/'r010-complete-compact-publication';m=json.loads((O/'remote/manifest.json').read_text());z=zipfile.ZipFile(O/'remote/remote.zip');bad=[]
repair=None
if mode=='repaired':
 D=B/'r010-complete-repair-publication';repair=json.loads((D/'manifest.json').read_text());rz=zipfile.ZipFile(D/'forensic-encoding-repair.zip')
for x in m['derived_raw_objects']:
 if repair and x['path'] in repair['replacement_objects']:
  x=repair['replacement_objects'][x['path']];raw=rz.read(x['encoded_member'])
 else:raw=z.read(x['encoded_member'])
 if len(raw)!=x['encoded_bytes'] or hashlib.sha256(raw).hexdigest()!=x['encoded_sha256']:bad.append(x['path'])
print(json.dumps({'mode':mode,'checked':len(m['derived_raw_objects']),'mismatched':bad}));assert not bad,'Actual derived-object manifest/member mismatch'
