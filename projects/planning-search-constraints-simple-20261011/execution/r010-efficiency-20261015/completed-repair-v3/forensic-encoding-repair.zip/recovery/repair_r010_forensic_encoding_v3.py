"""Repair two known invalid derived encodings; immutable byte-buffer ZIP binding, no native rerun."""
import pathlib,json,hashlib,zipfile,subprocess,tempfile,datetime,shutil
B=pathlib.Path(__file__).resolve().parent/'planning-resume-20261014';V=B/'r010-complete-compact-publication';O=B/'r010-complete-repair-publication';O.mkdir(exist_ok=False);m=json.loads((V/'remote/manifest.json').read_text());basis=V/'remote/control.sqlite3';basezip=V/'remote/remote.zip';repl={};members={}
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while q:=f.read(1048576):h.update(q)
 return h.hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
assert sha(basezip)==m['archive_sha256'];assert sha(basis)==m['members']['windows/W0005/.research-autopilot/simple-loop.sqlite3']['sha256']
archive=O/'forensic-encoding-repair.zip'
with zipfile.ZipFile(basezip) as old,zipfile.ZipFile(archive,'w',zipfile.ZIP_STORED) as z:
 for i,x in enumerate(m['derived_raw_objects']):
  original=old.read(x['encoded_member'])
  if len(original)==x['encoded_bytes'] and hashlib.sha256(original).hexdigest()==x['encoded_sha256']:continue
  raw=B/'project'/x['path'];assert sha(raw)==x['sha256'] and raw.stat().st_size==x['bytes']
  cmd=['zstd','-T1','-3','--patch-from='+str(basis),str(raw),'-c'];p=subprocess.run(cmd,capture_output=True,timeout=90);assert p.returncode==0;encoded=p.stdout;h=hashlib.sha256();count=0
  with tempfile.TemporaryFile() as inp:
   assert inp.write(encoded)==len(encoded);inp.flush();inp.seek(0)
   with (O/f'decode-{i:02d}.stderr.log').open('wb') as se:
    decoder=subprocess.Popen(['zstd','-d','-M2048MB','--patch-from='+str(basis),'-c'],stdin=inp,stdout=subprocess.PIPE,stderr=se)
    while q:=decoder.stdout.read(1048576):h.update(q);count+=len(q)
    rc=decoder.wait(timeout=90)
  assert rc==0 and count==x['bytes'] and h.hexdigest()==x['sha256'];name=f'forensic-repair/temp-sqlite-{i:02d}-v3.zst';z.writestr(name,encoded);eh=hashlib.sha256(encoded).hexdigest();members[name]={'bytes':len(encoded),'sha256':eh,'mode':384};repl[x['path']]={**x,'encoded_member':name,'encoded_bytes':len(encoded),'encoded_sha256':eh,'supersedes_encoding':{'base_commit':'fc5c8e4ca766ead5b3f26bbaf6b9e16d0bec6cf7','member':x['encoded_member'],'actual_packaged_bytes':len(original),'actual_packaged_sha256':hashlib.sha256(original).hexdigest()},'local_roundtrip':{'decoded_bytes':count,'decoded_sha256':h.hexdigest(),'exit':rc},'immutable_buffer_binding':True}
  assert sha(raw)==x['sha256'];print(json.dumps({'repaired':x['path'],'raw':count,'encoded':len(encoded)}),flush=True)
 assert len(repl)==2
 for p,n in [(pathlib.Path(__file__),'recovery/repair_r010_forensic_encoding_v3.py'),(pathlib.Path(__file__).parent/'test_r010_derived_member_binding_v1.py','recovery/test_r010_derived_member_binding_v1.py'),(pathlib.Path(__file__).parent/'diagnose_r010_remote_encoded_write_v1.py','recovery/diagnose_r010_remote_encoded_write_v1.py'),(B/'recovery-20261015/r010-encoding-binding-red-v1.log','recovery/encoding-binding-red-v1.log'),(B/'recovery-20261015/r010-complete-remote-proof-v2.log','recovery/failed-remote-proof-v2.log'),(B/'recovery-20261015/r010-remote-write-diagnostic-v1.log','recovery/write-diagnostic-v1.log')]:
  raw=p.read_bytes();z.writestr(n,raw);members[n]={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':420}
with zipfile.ZipFile(archive) as z:
 for n,x in members.items():raw=z.read(n);assert len(raw)==x['bytes'] and hashlib.sha256(raw).hexdigest()==x['sha256']
manifest={'format':'lossless-derived-encoding-repair-overlay-v1','base_packet_commit':'fc5c8e4ca766ead5b3f26bbaf6b9e16d0bec6cf7','base_manifest':'execution/r010-efficiency-20261015/completed-v2/manifest.json','base_manifest_sha256':sha(V/'remote/manifest.json'),'base_archive_sha256':m['archive_sha256'],'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'members':members,'replacement_objects':repl,'derived_resolution':'For each base derived raw object, replace only entries whose path appears in replacement_objects. Use encoded bytes from repair ZIP for replacements, base ZIP for others; all decode against exact canonical31basis from base ZIP. Retain old incomplete encoded members as forensic history.','canonical31_basis_sha256':sha(basis),'window_budget':m['window_budget'],'cycles':10,'prior_alias_bindings':len(m['unchanged_source_aliases']),'all_raw_data_inputs_unchanged':True,'cause':'Two named encoded scratch files were full and roundtrip-valid when first hashed, but shorter by ZIP capture. Exact mutation cause unknown. Missing final manifest-to-member binding check is a confirmed archiver fail-open, now regression-tested; not a native/CPU/RAM failure or priorcorruption explanation.','scope':'Two derived encoding replacements only; all scientific logs/results/31control/code and other raw-object encodings inherit immutable fc5packet unchanged. Not whole scratch/currentDB repair/cleanup.'};write(O/'manifest.json',manifest);print(json.dumps({'replacements':len(repl),'repair_zip_bytes':archive.stat().st_size,'sha256':manifest['archive_sha256']}))
