import hashlib,json,pathlib,sys
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE/'project/windows/W0005'
sys.path.insert(0,str(BASE/'rsi-simple-13/scripts'))
from simple_runner import SimpleRunner
status=SimpleRunner(ROOT).status()
assert status['budget']['attempts_used']==2 and status['budget']['reserved_seconds']==0
assert all(a['state']=='terminal' for a in status['attempts'])
rows=[];raw_refs=[]
def ref(path):
    p=ROOT/path;return {'path':path,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for arm in ['states_ops','none']:
    task='R005L2-depots-p05-'+arm+'-600s-3000M-W5-v1';attempt=next(a for a in status['attempts'] if a['task_id']==task)
    folder='results/'+task;result=json.loads((ROOT/folder/'result.json').read_text());metrics=json.loads((ROOT/folder/'command/metrics.json').read_text());sidecar=json.loads((ROOT/folder/'native-exit-status.json').read_text());config=json.loads((ROOT/'plans/configs'/str(task+'.json')).read_text())
    assert result['native_launched'] and result['valid_observation'] and result['native_CPU_accounting_complete']
    assert config['native_AS_bytes']==sidecar['native_AS_bytes']==3145728000
    assert config['native_CPU_seconds']==sidecar['native_CPU_soft_seconds']==600
    assert metrics['threads']==1 and metrics['cpu_affinity']==[0] and metrics['shared_cgroup_abort_bytes'] is None and metrics['prelaunch_reserved_bytes']==0
    assert result['binary_sha256']=='8f86d760cb8aac55b8b2eccc1cc8f435bff73ceff9f489fc0967a991979e12a9'
    assert result['source_manifest_sha256']=='a0a347552c7d42114078058d316d82e7828b26e949b00a05e1132bd332f3d4ed'
    assert result['sas_sha256']=='164b71eede20d07dc1ee0a412f8d4197a8acbb63292ee76d6db5e824339b39bd'
    assert result['native_exit_status']==sidecar
    if sidecar['native_process_returncode']==0:assert result['VAL_valid'] is True and result['cost'] is not None
    else:assert sidecar['native_process_returncode'] in [22,23] and result['cost'] is None and result['VAL_valid'] is None
    refs=[ref(folder+'/'+name) for name in ['result.json','native-exit-status.json','native-launch.json','output.sas','command/metrics.json','command/stdout.log','command/stderr.log']]
    refs += [attempt['receipt_ref'],ref('plans/configs/'+task+'.json')]
    raw_refs += refs
    rows.append({'arm':arm,'task_id':task,'attempt_id':attempt['attempt_id'],'native_exit':sidecar['native_process_returncode'],
                 'outcome':result['outcome'],'native_CPU_seconds':sidecar['native_reaped_child_cpu_seconds'],
                 'native_max_RSS_bytes':sidecar['native_reaped_child_max_RSS_bytes_linux'],
                 'sampled_process_group_RSS_bytes':metrics['peak_process_group_rss_bytes_sampled'],
                 'guard_wall_seconds':metrics['wall_seconds'],'memory_events_after':metrics['memory_events_after'],
                 'cost':result['cost'],'independent_VAL':result['VAL_valid'],'raw_refs':refs})
analysis={'schema':1,'question':'Does the unchanged original public Depots p05 search finish within600CPU/3000MnativeAS after the outerRSS wrapper has been corrected?',
          'rows':rows,'frozen_native_CPU_seconds':600,'native_AS_bytes':3145728000,'outer_group_RSS_bytes':3350000000,
          'public_development_condition_count':1,'new_valid_native_attempts':2,'raw_refs':raw_refs,
          'denominator':{'R005_original_configurations':4,'R005L1_extended_configurations':2,'R005L2_invalid_outerRSS_trial':1,'R005L2_new_valid_matched_arms':2,
                         'all_observed_related_configurations':9,'Depots_attempts_including_invalid_outerRSS_trial':7,'old_v3_queued_but_unexecuted_counted_as_native':0},
          'predecessor_native_memory_censored_2500M':'states_ops339.01CPU/none300.16CPU, original nativeexit22 and raw logs retained; separate historical envelope, not a causal speed comparison.',
          'invalid_old_v2':'Real291.999wall outerRSSguard3e9 trial retained separately; nativeCPU incomplete. Not relabeled nativeAS22 or no-launch.',
          'interpretation':'Classify actual native success or memory/time censoring only. No plan under a finite envelope does not prove unsolvability or host8GiB insufficiency. No algorithm, speed, novelty or holdout claim.',
          'next_action':'Use complete two-arm results to select the next discriminating source/native question; do not blindly repeat failures or indefinitely raise memory. Intermediate per-split graph witness and broader native conditions remain unresolved.',
          'project_floor':{'attempts':283+status['budget']['attempts_used'],'command_seconds':15590.955507759041+status['budget']['elapsed_seconds']},
          'timing_scope':'SAS-only originalnative solve; direct reapednativeCPU separate from wrapperwall, excludes translation/preflight/hash/independentVAL/archive. One exposed condition; censored runs are not performance wins.'}
(ROOT/'results/W5-depots-L2-matched-analysis-v1.json').write_text(json.dumps(analysis,indent=2)+'\n')
print(json.dumps({'rows':[{k:v for k,v in r.items() if k!='raw_refs'} for r in rows],'project_floor':analysis['project_floor']}))
