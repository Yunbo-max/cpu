"""Prospective W5 task selection; no command execution and no private SQL edits."""
import copy, datetime, hashlib, json, pathlib, sys
import zstandard
BASE=pathlib.Path(__file__).resolve().parent
ROOT=BASE/'project/windows/W0005'
sys.path.insert(0,str(BASE/'rsi-simple-13/scripts'))
import research_reasoning as reasoning
from simple_runner import SimpleRunner

def ref(path):return {'path':path,'sha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest()}
def write(path,obj):
    p=ROOT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,allow_nan=False)+'\n');return ref(path)

def prepare(arm='states_ops'):
    runner=SimpleRunner(ROOT);status=runner.status()
    assert status['budget']['reserved_seconds']==0 and not any(a['state']!='terminal' for a in status['attempts'])
    assert not status['stop_requested']
    if arm=='none':
        first=ROOT/'results/R005L2-depots-p05-states_ops-600s-3000M-W5-v1/result.json'
        observed=json.loads(first.read_text())
        assert observed['native_launched'] and observed['valid_observation'], 'Diagnose invalid first-arm execution before matched continuation'
    with (BASE/'accepted-v3-complete-stdout.json.zst').open('rb') as f,zstandard.ZstdDecompressor().stream_reader(f) as z:prior=json.load(z)
    task_id=f'R005L2-depots-p05-{arm}-600s-3000M-W5-v1'
    previous=status['journal']['current_research_review']
    decision=copy.deepcopy(json.loads((ROOT/previous['path']).read_text()))
    old_config=f'plans/configs/R005L2-depots-p05-{arm}-600s-3000M-host-v3.json'
    config=json.loads((ROOT/old_config).read_text())
    config['run_id']=task_id
    config['continues_unexecuted_predecessor_task']=f'W0004/R005L2-depots-p05-{arm}-600s-3000M-host-v3'
    config['new_window_is_not_independent_sample']=True
    config['input_refs'] += [ref('W5_SUCCESSOR.json'),ref('evidence/W5-journal-replay-and-initialization-proof.json')]
    config_ref=write('plans/configs/'+task_id+'.json',config)
    handoff=write('evidence/'+task_id+'-handoff.json',{
        'old_window':'W0004','new_window':'W0005','old_task_never_native_launched':True,
        'old_task_id':f'R005L2-depots-p05-{arm}-600s-3000M-host-v3','new_task_id':task_id,
        'old_depends_on':['R007-cpu-overhead-r3-counts-host-v1'] if arm=='states_ops' else [],
        'old_dependencies_consumed_as_historical_receipts_not_new_tasks':True,
        'scientific_conditions':'Original binary/source/SAS/search/seed/thread, native600CPU/3000M AS, outer650wall/RSS3.35GB/AS3.5GB, host-only memory policy; only new output ID/window differs.',
        'previous_accepted_decision':previous,'prior_native_attempts':69,'prior_project_attempt_floor':283,
        'prior_project_command_seconds_floor':15590.955507759041,'historical_cycles':4,
        'old_native_RSS_guard_failure_retained':True,'is_algorithm_change':False})
    external=[]
    for a in prior['attempts']:
        external.append({'attempt_id':a['attempt_id'],'task_id':a['task_id'],'receipt_ref':a['receipt_ref'],
                         'valid_execution':a.get('result')=='succeeded','feedback_kind':'inquiry'})
    for a in status['attempts']:
        if a['state']=='terminal':
            external.append({'attempt_id':a['attempt_id'],'task_id':a['task_id'],'receipt_ref':a['receipt_ref'],
                             'valid_execution':a.get('result')=='succeeded','feedback_kind':'inquiry'})
            observation={'id':'obs-'+a['attempt_id'],'attempt_id':a['attempt_id'],'task_id':a['task_id'],
                         'receipt_ref':a['receipt_ref'],'outcome':'invalid' if a.get('result')!='succeeded' else 'supports',
                         'result_ref':ref('results/'+a['task_id']+'/result.json'),'affected_layer':'evaluation','affected_explanation_ids':[],
                         'interpretation':'Actual bounded native envelope observation; native memory/time censoring is preserved and is not solver unsolvability or superiority. Runtime failed status is not positive hypothesis support.'}
            # Only select none after actually reading the states_ops result.
            if not any(o['attempt_id']==a['attempt_id'] for o in decision['inquiry']['observations']):
                decision['inquiry']['observations'].append(observation)
                decision['inquiry']['based_on_observation_ids'].append(observation['id'])
    feedback_ref=write('evidence/'+task_id+'-external-prior-feedback.json',external)
    decision['decision_id']='W5-'+task_id+'-selection-v1'
    decision['previous_ref']=previous
    decision['selected_task_ids']=[task_id]
    decision['evidence_change']='boundary'
    decision['evidence_refs'] += [handoff,feedback_ref,ref('W5_SUCCESSOR.json'),ref('evidence/W5-journal-replay-and-initialization-proof.json')]
    decision['why_selected']=('Finish the previously accepted but never executed native memory-envelope diagnostic after an expired finite window and verified public-API scientific-journal reconstruction; no rerun of any finished experiment.' if arm=='states_ops' else 'Prospectively select the declared matched none arm after reading the actual valid states_ops bounded outcome. The old none configuration was prepared but never registered/executed; this is its first real selection, not replay of an accepted queued task or completed experiment.')
    decision['strategy_reassessment']='All69old physical attempts are terminal and retained. New W5 carries283/15590.955507759041 project floor and4historical cycles; no oldDB/stop/deadline edits. This one bounded original native diagnostic is useful before investing in per-split observers; local failure or completion does not finish the research goal.'
    iq=decision['inquiry'];iq['question']=f'Can original Depots {arm} search finish within the already frozen600CPU/3000M native envelope when the prospective corrected outer3.35GB RSS wrapper actually runs?'
    iq['change_reason']='Actual finite predecessor deadline elapsed; lossless public journal replay and linked W5 carry preserve scientific conditions, old failures, source and total effort. New task/output identity only.'
    iq['next_check']['task_ids']=[task_id];iq['next_check']['question']=iq['question']
    iq['next_check']['input_refs']=config['input_refs']+[config_ref,handoff,feedback_ref]
    decision_ref=write('plans/'+task_id+'-decision-v4.json',decision)
    task={'task_id':task_id,'argv':['python3','scripts/run_r005l2_host_only_native_sas_v3.py','--config',config_ref['path']],
          'phase':'diagnostic','purpose':iq['question'],'timeout_seconds':675,'cwd':'.','depends_on':[],
          'input_refs':config['input_refs']+[config_ref,handoff,feedback_ref,decision_ref],
          'outputs':['results/'+task_id+'/result.json'],'research_scope':'diagnostic','reasoning_ref':decision_ref}
    report=reasoning.check_task(ROOT,task,candidate_id=prior['journal']['active_idea'])
    write('evidence/'+task_id+'-reasoning-preflight.json',report)
    if report['gaps']:raise RuntimeError('preflight gaps: '+json.dumps(report['gaps']))
    reasoning.require_host_feedback(ROOT,task,external)
    write('plans/'+task_id+'-task.json',task)
    print(json.dumps({'task_id':task_id,'reasoning_ref':decision_ref,'prior_host_receipts_consumed':len(external),'gaps':report['gaps']}))

if __name__=='__main__':prepare(sys.argv[1] if len(sys.argv)>1 else 'states_ops')
