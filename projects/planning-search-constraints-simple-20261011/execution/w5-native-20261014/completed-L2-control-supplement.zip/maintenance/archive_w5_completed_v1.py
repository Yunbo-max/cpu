"""Versioned incremental W5 control/result supplement, preserving prior archives.

SQLite backup API supplies a consistent active-state snapshot; this is not a
claim that an in-flight native task has completed or that every scratch byte is
archived. Unchanged inputs remain in the immutable core68 archive by hash.
"""
import datetime,hashlib,json,pathlib,shutil,sqlite3,sys,zipfile
BASE=pathlib.Path(__file__).resolve().parent;ROOT=BASE/'project/windows/W0005';OUT=BASE/'final-publication';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(BASE/'rsi-simple-13/scripts'))
from simple_runner import SimpleRunner
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
runner=SimpleRunner(ROOT);s=runner.status();assert s['budget']['attempts_used']==2
states=next(a for a in s['attempts'] if '-states_ops-' in a['task_id']);none=next(a for a in s['attempts'] if '-none-' in a['task_id'])
assert states['state']==none['state']=='terminal' and s['budget']['reserved_seconds']==0;res=json.loads((ROOT/'results'/states['task_id']/'result.json').read_text());metrics=json.loads((ROOT/'results'/states['task_id']/'command/metrics.json').read_text())
assert res['valid_observation'] and res['native_exit_status']['native_process_returncode']==22 and res['native_CPU_accounting_complete']
snapshot=OUT/'consistent-terminal-W5.sqlite3'
if snapshot.exists():snapshot.unlink()
with sqlite3.connect((ROOT/'.research-autopilot/simple-loop.sqlite3').as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(snapshot) as dst:src.backup(dst)
with sqlite3.connect(snapshot) as c:
    assert c.execute('pragma integrity_check').fetchone()[0]=='ok'
    st=json.loads(c.execute('select payload from runner_state where id=1').fetchone()[0]);assert st['attempts_used']==2
cur=json.loads((BASE/'dispatch-publication/CURRENT_EXECUTION.json').read_text())
cur.update(updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status_observed=s['status'],window_budget=s['budget'],actual_health=runner.health(),active_or_unknown_attempts=sum(a['state']!='terminal' for a in s['attempts']))
cur['project_ledger'].update(window_attempts=2,window_command_seconds=s['budget']['elapsed_seconds'],combined_attempt_floor=285,combined_command_seconds_floor=15590.955507759041+s['budget']['elapsed_seconds'])
cur['current_accepted_decision']=s['journal']['current_research_review']
cur['native_L2_W5']={'states_ops':res,'states_ops_metrics':metrics,'none':{'task_id':none['task_id'],'attempt_id':none['attempt_id'],'state':none['state'],'contract_sha256':none['contract_sha256'],'not_yet_a_terminal_result':none['state']!='terminal'}}
cur['active_coordinator'].update(native_attempt=none['attempt_id'],task_id=none['task_id'])
cur['automation_operational_pause']={'is_enabled':True,'automation_id':'6ace5c4436ac8191acfcc79f74105e52','same_existing_task':True,'next_run_time_returned':None,'no_precise_wake_or_residency_guarantee':True}
cur['next_task']='Observe/settle original none attempt '+none['attempt_id']+'; do not repeat either states_ops or completed old experiments. Read actual native receipt/sidecar/logs, then analyze complete matched L2 denominator before selecting next scientific action.'
cur['current_control_snapshot_scope']='Consistent activeW5 control2 + all completed states_ops raw output and new none inputs/dispatch; overlay supplement to b24W5base, core68oldinputs and69forensics. No terminal none or full scratch-filesystem claim.'
for name in ['CURRENT_EXECUTION.json','CHECKPOINT.json']:write(OUT/name,cur)
(OUT/'RESUME.md').write_text('Use latest CURRENT_EXECUTION and W5_SUCCESSOR_LATEST first. Sole finite queue W0005, fixedSimple13digest0022b214e957337ba9035f77ed7036cfaa51d11cb467ac0d6b99df5b0fa96336. OldW4badDB/deadline andW3userstop preserved. W5scientificjournal rebuilt with publicAPIs; original139history/4cycles retained. Project lowerfloor=283+actualW5attempts and15590.955507759041+actualW5commandsec; do not double-add replayed journalusage. states_ops-W5-v1 genuinely completed native22/354.407594nativeCPU/3133698048nativeRSS/no plan/hostOOM0, complete raw logs retained. none-W5-v1 currently '+none['state']+' attempt '+none['attempt_id']+'; inspect actualphysicalreceipt before any action. Do not restore queued0baseline and duplicate active2. New activecontrol backup preserves reservation/identity; unobservable worker staysunknown until receipt/reconcile evidence. Existing hourly task enabled; no exact wake/residency guarantee. Kernel-only overallmemory policy, frozen600CPU/3000MnativeAS/650wall/3.35GBRSS/3.5GBouterAS/thread1. No completed R005/R005L1/R006/R007 reruns.\n')
(OUT/'CURRENT_RESEARCH.md').write_text('# 当前规划、搜索与约束求解研究\n\nW5已通过原版Simple13公开接口接续：原139条科学历史、4个既有周期、失败和总账保留，旧W4损坏库未覆盖。现唯一串行队列工作中。\n\nR005/R005L1原6行结果全部保留；延长时间后Depots两臂在2500M原生AS下exit22。R006/R007完成的计数/粗细插桩对照和图资格不重跑。10,000状态12项均cost24独立VAL，计数/搜索工作一致，但CPU开销比率方向仍反转；没有稳定速度或新颖性结论。最终图见证不替代每split/全trajectory证明。\n\n本次新结果：Depots states_ops同源/同SAS/同搜索/单线程、600CPU和3000M原生AS，使用修正的3.35GB外RSS包装器，真实nativeCPU354.407594秒后exit22，无计划；原生reaped最大RSS3133698048B，进程组sampled峰值3144183808B，宿主OOM/kill0。它是有效原生内存删失，不是数据库故障、包装器提前终止、CPU不足或不可解证明。原生地址空间限额是前瞻冻结实验条件；撤销的整机8GB/cache启动门槛没有恢复。\n\n匹配none臂已消费69旧回执和该新回执后独立选择并开始运行，尚无终态结论。两臂完成后保留完整失败分母分析原生边界，再选择每split图见证或完整native多public条件等有决策价值的下一项；不无限升配或重复同一失败。原控制库损坏触发原因仍未知；后继恢复成功不等于旧库已修复。\n')
(OUT/'W5_RECOVERY_REPORT.zh-CN.md').write_text('本次已恢复实际实验执行：旧有限W4真实到界后，经固定Simple13公开API重放原139历史，独立审查确认科学状态和4旧周期未丢，新W5库integrity正常。前283次/15590.955507759041命令秒floor继续累计，旧坏库/旧stop/失败未清。states_ops首次正确wrapper原生执行已真实完成：CPU354.407594秒，nativeexit22，原生RSS3133698048B，组sampled3144183808B，无plan/VAL、无宿主OOM。当前none配对臂真实运行中，不称已成功。源/binary/SAS/搜索/seed/thread及600CPU/3000M原生AS不变；新旧失败分母完整保留。原小时钟已重新启用，下一唤醒时间字段未返回，不能保证整点或常驻。\n')
core=json.loads((BASE/'core68-manifest.json').read_text());old_hashes={x['sha256'] for x in core['files']};old_by_hash={x['sha256']:x for x in core['files']}
archive=OUT/'completed-L2-control-supplement.zip';members={};excluded=[];aliases=[]
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def add(p,name):
        digest=sha(p);z.write(p,name);members[name]={'bytes':p.stat().st_size,'sha256':digest}
    add(snapshot,'windows/W0005/.research-autopilot/simple-loop.sqlite3')
    for p in ROOT.rglob('*'):
        if not p.is_file():continue
        relative=str(p.relative_to(ROOT))
        if relative=='.research-autopilot/simple-loop.sqlite3' or relative.startswith('.research-autopilot/simple-loop.sqlite3-'):continue
        if relative.endswith('.lock') or '__pycache__' in p.parts:continue
        if relative.startswith('history/W0004/accepted-v3-complete-stdout'):
            excluded.append({'path':relative,'sha256':sha(p),'retained_in':'Verified old69 forensic tar manifest; not removed'});continue
        if none['state']!='terminal' and relative.startswith('results/'+none['task_id']+'/') and p.name!='native-launch.json':
            excluded.append({'path':relative,'reason':'Active mutable output, not a terminal result'});continue
        digest=sha(p)
        if digest in old_hashes:
            old=old_by_hash[digest]
            aliases.append({'path':'windows/W0005/'+relative,'bytes':p.stat().st_size,'sha256':digest,'pack':old['pack'],'member':old['member'],'mode':p.stat().st_mode & 0o777})
            continue
        add(p,'windows/W0005/'+relative)
    add(BASE/'verify_w5_remote_v2.py','maintenance/verify_w5_remote_v2.py')
    add(BASE/'archive_w5_completed_v1.py','maintenance/archive_w5_completed_v1.py')
manifest={'schema':1,'format':'ZIP_DEFLATED incremental overlay supplement','archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'members':members,
          'unchanged_W5_input_aliases':aliases,'base_W5_packet_commit':'b24f8f4bde8da307677ab340df004823bb4cc563','base_W5_packet_sha256':'9d5c670e670d53be81606c1d2416e853927496d39d407e8911b5228608668208',
          'unchanged_inputs_core68_manifest_sha256':'af0708304697337f7c36b1cac238167fa2522bee75a4aad5df12b909484b328f','all_prior_packs_members_retained':True,
          'predecessor_W4_not_overwritten':True,'window_budget':s['budget'],'new_control_integrity_check':'ok','excluded_retained_objects':excluded,
          'scope':'Consistent terminalW5 control2/reservation0, both actual native22 matched results and all rawlogs/metrics/sidecars/receipts/configs, analysis5scopedcycles, newrecoverycontracts. All unchanged input aliases and all prior packs retained by immutablebase reference. Old69badraw accepted export remains independently verified forensic reference. Not allrawscratch or originalW4DBrepair.'}
write(OUT/'completed-L2-manifest.json',manifest)
print(json.dumps({'archive_bytes':manifest['archive_bytes'],'members':len(members),'excluded':len(excluded),'none_attempt':none['attempt_id'],'window_budget':s['budget']}))

# Override operational metadata with the actual complete matched outcome.
analysis=json.loads((ROOT/'results/W5-depots-L2-matched-analysis-v1.json').read_text())
none_result=json.loads((ROOT/'results'/none['task_id']/'result.json').read_text())
cur['native_L2_W5']['none']=none_result
cur['project_ledger']['actual_scoped_research_cycles']=len(s['journal']['research_cycles'])
cur['active_coordinator']={'single_queue':'W0005','supervisor_started':bool(runner.health().get('identity_observed_alive')),'owned_exec_session':54552,'native_active_or_unknown':0,'last_native_attempt':none['attempt_id']}
cur['next_task']='Both L2arms terminal. Consume all69prior+2W5actual receipts before the next v4decision; prioritize missing per-split graph witness/source invariants and fullnative/multiplepublicconditions. Do not repeat completed runs or indefinitely raise memory.'
cur['current_control_snapshot_scope']=manifest['scope']
for name in ['CURRENT_EXECUTION.json','CHECKPOINT.json']:write(OUT/name,cur)
(OUT/'RESUME.md').write_text('Current solequeue W0005. Both nativeL2arms finished native22 with completeCPU/RSS and nohostOOM; all2attempts terminal/reservation0. Restore latest W5_SUCCESSOR_LATEST completionpacket over immutablebase inputs if needed; do not restore0baseline or rerun completed tasks. Simple13digest0022b214e957337ba9035f77ed7036cfaa51d11cb467ac0d6b99df5b0fa96336, priorfloor283/15590.955507759041 + W5actual2/713.0129625419995 = globalfloor285/16303.96847030104, five scopedcycles incl4inherited and1newmatchedtest. OldW3stop, W4badSQLite/deadline and69failed/cancelled histories retained; no privateSQL edit/sourceupgrade. Existing hourly task enabled; no exactwake/residency guarantee. Next actualsourcequestion is per-split graphwitness/read-onlyhook semantic invariants before propagationoptimization, with all69+2hostfeedback and latestaccepteddecision consumed. No globalcache/headroom gates, onlykernelhardlimit and frozenpertaskcaps. Continuousgoal notcompleted orstopped.\n')
(OUT/'CURRENT_RESEARCH.md').write_text('# 当前规划、搜索与约束求解研究\n\nW5实际恢复成功：Simple13固定源码公开API重放原139历史，科学状态/4旧周期/失败/usage完整，新库完整性正常；旧坏库未覆盖。\n\n原R005/R005L1六行和W4一次错误RSS包装器试验全部保留。R006/R007既有对照不重跑：R007 10,000状态12项cost24独立VAL通过、计数和搜索工作一致，但开销比例仍反转；没有稳定速度或新颖性结论。最终图见证不替代每split/全trajectory证明。\n\n本次新增完整匹配L2：相同原source/binary/SAS/search/seed/thread，600CPU/3000M原生地址空间和修正版3.35GB组RSS保护。states_ops实际nativeCPU354.407594秒、原生RSS3133698048B，none实际nativeCPU356.928411秒、原生RSS3136704512B；均nativeexit22、无计划/VAL、无宿主OOM/kill，外部RSS保护未先终止。它们是有效原生地址空间删失；不证明问题不可解、整机8GiB不足或算法快慢。未恢复人为整机/cache启动阈值。\n\n当前W5两次attempt均terminal/0reservation，项目lowerfloor285次/16303.96847030104命令秒；命令记账含历史保守结算，非精确CPU或科研周期。已记录第五个scoped研究周期：原4个保留，本次两臂组成1个有预测与实际阴性结果的资源边界检验，不把两个attempt算两个周期。\n\n继续方向：消费69+2真实回执，优先补每split只读图见证与源码不变量，再决定传播优化；完整native、多公开条件、强简单对照、新颖性主原文/作者代码证据仍欠。不能无限升配或重复失败。持续目标未完成/未stop，原小时钟已启用；控制库初始损坏触发原因仍未知。\n')
(OUT/'W5_RECOVERY_REPORT.zh-CN.md').write_text((OUT/'CURRENT_RESEARCH.md').read_text())
write(OUT/'completed-L2-analysis.json',analysis)
