"""Explicit incremental overlay; retain all immutable prior packs and known inflight identities."""
import pathlib,json,hashlib,sqlite3,zipfile,datetime,sys,shutil
B=pathlib.Path(__file__).resolve().parent;R=B/'project/windows/W0005';sys.path.insert(0,str(B/'rsi-simple-13/scripts'));from simple_runner import SimpleRunner
stage=sys.argv[1];O=B/'r008-publication'/stage;O.mkdir(exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while d:=f.read(1048576):h.update(d)
 return h.hexdigest()
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
runner=SimpleRunner(R);s=runner.status();health=runner.health();active=[a for a in s['attempts'] if a['state']!='terminal'];assert not s['stop_requested']
snapshot=O/'consistent-W5.sqlite3'
with sqlite3.connect((R/'.research-autopilot/simple-loop.sqlite3').as_uri()+'?mode=ro',uri=True) as src,sqlite3.connect(snapshot) as dst:src.backup(dst)
with sqlite3.connect(snapshot) as c:
 assert c.execute('pragma integrity_check').fetchone()[0]=='ok';state=json.loads(c.execute('select payload from runner_state where id=1').fetchone()[0])
 assert state['attempts_used']==s['budget']['attempts_used']
core=json.loads((B/'core68-manifest.json').read_text());old={x['sha256']:x for x in core['files']};members={};aliases=[];deferred=[]
archive=O/'control-source-supplement.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 def add(p,name):
  z.write(p,name);members[name]={'bytes':p.stat().st_size,'sha256':sha(p)}
 add(snapshot,'windows/W0005/.research-autopilot/simple-loop.sqlite3')
 # Full control and all new R008 code/contracts/evidence, plus source aliases. Active build products are deferred, never removed.
 for p in R.rglob('*'):
  if not p.is_file() or '__pycache__' in p.parts:continue
  rel=str(p.relative_to(R));include=False
  if rel.startswith('vendor/cmake-3.31.6/') or rel.endswith('.lock') or rel.startswith('.research-autopilot/simple-loop.sqlite3'):continue
  if rel.startswith('.research-autopilot/') or 'R008' in rel or 'r008' in rel:include=True
  if not include:continue
  if rel.startswith('results/R008-observer-build-W5-v2/build/'):
   deferred.append({'path':rel,'reason':'Compiler products, active or rebuildable; no full scratch archive claim'});continue
  if any(rel.startswith('results/'+a['task_id']+'/') or rel.startswith('results/'+a['task_id']+'-guard/') for a in active):
   if p.name.endswith('.log'):
    # Explicit observational copy, never replay an incomplete stream onto a live native result.
    add(p,'observations/'+rel)
   else:deferred.append({'path':rel,'reason':'Known active mutable output; actual worker/reservation in consistent control'})
   continue
  h=sha(p)
  if h in old:
   x=old[h];aliases.append({'path':'windows/W0005/'+rel,'bytes':p.stat().st_size,'sha256':h,'pack':x['pack'],'member':x['member']});continue
  add(p,'windows/W0005/'+rel)
 add(B/'archive_r008_stage_v1.py','maintenance/archive_r008_stage_v1.py')
man={'format':'ZIP_DEFLATED incremental overlay supplement','stage':stage,'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive),'members':members,'unchanged_source_aliases':aliases,'core68_manifest_sha256':sha(B/'core68-manifest.json'),'prior_complete_W5_L2_commit':'0e3b9d4026d6e88a2928ad07be32bb974d7dd292','prior_W5_completed_packet_commit':'9128ad4b88dcf2e172af2996f92fea409260d5ae','prior_W5_completed_packet_sha256':'b0541172c75cc3eb060c4ed7446b2d314049b99530b6a5ecdde11f6598a749a0','dependency_manifest':'execution/r008-observer-20261014/cmake-dependency-manifest.json','all_prior_packs_members_retained':True,'window_budget':s['budget'],'actual_active_or_unknown':[{'task_id':a['task_id'],'attempt_id':a['attempt_id'],'state':a['state'],'contract_sha256':a['contract_sha256']} for a in active],'control_integrity_check':'ok','deferred_objects':deferred,'scope':'Consistent actual W5 control, all new R008 source/contracts/evidence/terminal logs; known active products observational/deferred. Full parent source aliases and isolated CMake dependency separately retained. All prior packs by reference. Not all scratch filesystem or old W4 DB repair.'};write(O/'manifest.json',man)
cur=json.loads((B/'r008-publication/base-CURRENT_EXECUTION.json').read_text());cur.update(updated_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),status_observed=s['status'],window_budget=s['budget'],actual_health=health,active_or_unknown_attempts=len(active),current_accepted_decision=s['journal']['current_research_review'],next_task='Read actual R008 build receipt/identity, then freeze/admit exact1000 per-split native witness qualification; consume all69old+latestW5 feedback. Do not rerun completed L2 or old measurement batches.',current_control_snapshot_scope=man['scope']);cur['project_ledger'].update(window_attempts=s['budget']['attempts_used'],window_command_seconds=s['budget']['elapsed_seconds'],combined_attempt_floor=283+s['budget']['attempts_used'],combined_command_seconds_floor=15590.955507759041+s['budget']['elapsed_seconds'],actual_scoped_research_cycles=len(s['journal']['research_cycles']));cur['R008']={'actual_active_or_unknown':man['actual_active_or_unknown'],'attempts':[{'task_id':a['task_id'],'attempt_id':a['attempt_id'],'state':a['state'],'result':a.get('result'),'receipt_ref':a.get('receipt_ref')} for a in s['attempts'] if a['task_id'].startswith('R008')],'native_witness_not_yet_qualified':not (R/'results/R008-split-witness-native-W5-v1/result.json').exists(),'evaluator_corrections':'v1 accepted three negative fixtures; v2 pins costs/INF/domain capacities and actual main-loop SP suffix/count. Synthetic checks are not native experiments.','source_boundary':'All actual refine paths observe after child commit; native SP omitted there and checked only post-update/final. Conservative parent modified_vars unchanged, opportunity not yet measured.'};cur['active_coordinator']={'single_queue':'W0005','owned_exec_session':38270,'observed_health':health,'active_or_unknown':man['actual_active_or_unknown']}
for name in ['CURRENT_EXECUTION.json','CHECKPOINT.json']:write(O/name,cur)
(O/'CURRENT_RESEARCH.md').write_text('# 规划约束研究接续\n\n既有R005/R006/R007与W5 Depots完整L2结果均保留，不重复、不无限升内存。持续目标和同一Simple13、单线程/单队列、内核整体内存政策不变。\n\n本次R008推进每次真实拆分后的只读图见证：恢复并逐SHA核验作者粗插桩源，独立源码审查确定提交边界；在该处不读取尚未更新的最短路，而在完成更新处另行读取。算法与旧modified_vars计算保持不变。源码发现它在传播收缩时保守地报告全坐标，先用实际轨迹量化，不称速度提升或正确性缺陷。\n\n构建v1因当前环境缺少CMake在编译前失败，非CPU/RAM不足。已安装固定CMake3.31.6并保留失败和新v2身份。最新实际状态以CURRENT_EXECUTION和物理receipt为准。构建成功不是native资格通过。初版检查器漏过缺失SP检查点、成本漂移、INF漂移三类合成反例，v2已修正并保存全部反例；这些是评估器检查，不是新规划样本或科学周期。\n\n原生资格要求每次拆分完整图/域/顺序/镜像与重数、稳定检查点独立64位最短路、最终原图/work/plan匹配及独立VAL；禁止把导出期间计时用于速度结论。独立算子语义oracle、多公开条件完整native效率、强简单对照和主要原文新颖性仍欠。\n')
(O/'RESUME.md').write_text('Use latest CURRENT_EXECUTION, W5_SUCCESSOR_LATEST and R008_OBSERVER_LATEST, immutable manifests and actual localstatus/health/inbox/receipts. SameW5, no newwindow or sourceupgrade. Known active IDs/reservation retained in consistent control; do not duplicate build/supervisor. V1 CMake absence is a real precompile engineering failure, not CPU unavailable; v2 uses isolated pinned CMake. Native observer not qualified until actual result/graph/work/VAL evidence. Observer post_refine has no stale native distances; v2auditor SP suffix count binds native forward+backward refinements. Old all71feedback+latest actual attempts required at each newv4decision. Kernel-only globalmemory policy; no cache/headroom gate. Priorprojectfloor283/15590.955507759041 plus actualW5budget, five prior scopedcycles; builds/fixtures are not cycles. Alloldstops/failures/deadlines/packs retained. Ongoingresearch notcompleted.\n')
print(json.dumps({'stage':stage,'archive_bytes':man['archive_bytes'],'members':len(members),'aliases':len(aliases),'active':man['actual_active_or_unknown'],'budget':s['budget']}))
