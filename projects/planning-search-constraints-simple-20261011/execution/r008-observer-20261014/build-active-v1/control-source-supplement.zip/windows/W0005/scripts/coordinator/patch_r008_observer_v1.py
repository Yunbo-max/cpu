from pathlib import Path
import json,hashlib
B=Path(__file__).resolve().parent;R=B/'project/windows/W0005';t=R/'vendor/scorpion_r008_observer_v1';p=t/'src/search/cartesian_abstractions/abstraction.cc';s=p.read_text();assert 'r008_snapshot' not in s
s=s.replace('#include "abstract_state.h"','#include "abstract_state.h"\n#include "shortest_paths.h"')
s=s.replace('using namespace std;','#include "r008_split_witness_v1.inc"\n\nusing namespace std;',1)
s=s.replace('    transition_system->add_loops_in_trivial_abstraction(*states[0], disambiguated);','    transition_system->add_loops_in_trivial_abstraction(*states[0], disambiguated);\n    r008_snapshot(*this, nullptr, task_properties::get_operator_costs(task_proxy), "initial");',1)
needle='    return {split_result.v1_id, split_result.v2_id, disambiguated_v1 || disambiguated_v2,';assert s.count(needle)==1
s=s.replace(needle,'    r008_snapshot(*this, nullptr, task_properties::get_operator_costs(task_proxy), "post_refine", v_id, split_result.v1_id, split_result.v2_id, var, modified_vars);\n\n'+needle);p.write_text(s)
p=t/'src/search/cartesian_abstractions/cegar.cc';s=p.read_text();s=s.replace('#include "r006_graph_export_v1.inc"','#include "r006_graph_export_v1.inc"\n#include "r008_split_witness_v1.inc"',1)
# Native SP is valid after the bulk preprocessing initialization and incremental update.
needle='    shortest_paths->initialize(';print('initialize anchors',s.count(needle));
# Inspected initialization is a recompute, use unique following profiling marker boundary instead below.
needle='    update_distances_timer.stop();';assert s.count(needle)==1
s=s.replace(needle,needle+'\n    r008_snapshot(*abstraction, shortest_paths.get(), task_properties::get_operator_costs(task_proxy), "sp_updated");',1)
needle='    r006_export_graph(*abstraction, *shortest_paths, task_properties::get_operator_costs(task_proxy));';assert s.count(needle)==1
s=s.replace(needle,'    r008_snapshot(*abstraction, shortest_paths.get(), task_properties::get_operator_costs(task_proxy), "final");\n'+needle,1);p.write_text(s)
files=[]
for p in t.rglob('*'):
 if p.is_file():files.append({'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(R/'data/R008-observer-source-manifest-v1.json').write_text(json.dumps({'parent_source_restore':'evidence/R008-full-observer-parent-source-restoration-v1.json','source_tree':str(t.relative_to(R)),'files':files,'changed_parent_files':['src/search/cartesian_abstractions/abstraction.cc','src/search/cartesian_abstractions/cegar.cc'],'added_files':['src/search/cartesian_abstractions/r008_split_witness_v1.inc'],'scope':'Readonly diagnostic export only; original algorithm, modified_vars computation and all clocks retained. Observer-inclusive timings ineligible.'},indent=2)+'\n')
