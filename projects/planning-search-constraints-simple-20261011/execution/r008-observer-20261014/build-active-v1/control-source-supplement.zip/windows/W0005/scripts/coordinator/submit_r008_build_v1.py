import json,sys,pathlib,datetime,hashlib,zstandard,os
B=pathlib.Path(__file__).resolve().parent;R=B/'project/windows/W0005';sys.path.insert(0,str(B/'rsi-simple-13/scripts'));from simple_runner import SimpleRunner
r=SimpleRunner(R);s=r.status();assert not s['stop_requested'] and not s['budget']['reserved_seconds'] and all(a['state']=='terminal' for a in s['attempts']);assert not pathlib.Path('/proc/4617').exists()
t=json.loads((R/'plans/R008-observer-build-W5-v1-task.json').read_text());assert t['task_id'] not in [x['task_id'] for x in s['tasks']]
resource={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'boot':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'cpu_count':os.cpu_count(),'kernel_only_global_memory':True}
for f in ['cpu.max','memory.max','memory.current','memory.stat','memory.events']:
 p=pathlib.Path('/sys/fs/cgroup')/f
 if p.exists():resource[f]=p.read_text()
(R/'evidence/R008-build-host-observation-v1.json').write_text(json.dumps(resource,indent=2)+'\n')
req=next(x['snapshot'] for x in s['requests'] if x['state']=='open');dr=t['reasoning_ref']
resp={'response_id':'W5-R008-build-respond-v1','request_id':req['request_id'],'idea':s['journal']['active_idea'],'revision':req['revision'],'goal_contract_version':req['goal_contract_version'],'reason':'All71 actual native receipts consumed; select source-isolated readonly per-split observer build, preserving old negative results and original goal.','events':[{'event_id':'W5-R008-build-review-v1','kind':'research_review','decision_ref':dr,'evidence':[dr],'reason':'Frozen readonly observer protocol and source boundary review; build only, no native success claim.'}],'tasks':[t]}
(R/'plans/R008-build-response-v1.json').write_text(json.dumps(resp,indent=2)+'\n');result=r.respond(resp);raw=json.dumps(result).encode();p=R/'evidence/R008-build-official-response-v1.json.zst';p.write_bytes(zstandard.ZstdCompressor().compress(raw));(R/'evidence/R008-build-official-response-v1-identity.json').write_text(json.dumps({'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'zstd_sha256':hashlib.sha256(p.read_bytes()).hexdigest()},indent=2)+'\n');print('accepted',t['task_id'])
