"""One coordinator, official respond, all historical and current receipt feedback."""
import copy,json,pathlib,hashlib,sys,zstandard,datetime,os
B=pathlib.Path(__file__).resolve().parent;R=B/'project/windows/W0005';sys.path.insert(0,str(B/'rsi-simple-13/scripts'));from simple_runner import SimpleRunner
import research_reasoning as reasoning

def ref(p):return {'path':p,'sha256':hashlib.sha256((R/p).read_bytes()).hexdigest()}
def write(p,x):(R/p).parent.mkdir(parents=True,exist_ok=True);(R/p).write_text(json.dumps(x,indent=2)+'\n');return ref(p)
def advance(template,reason):
 r=SimpleRunner(R);s=r.status();assert not s['stop_requested'] and not s['budget']['reserved_seconds'] and all(a['state']=='terminal' for a in s['attempts'])
 t=json.loads((R/template).read_text());next_actions=t.pop('_inquiry_outcome_actions',None);tid=t['task_id'];assert tid not in [a['task_id'] for a in s['tasks']]
 prev=s['journal']['current_research_review'];d=copy.deepcopy(json.loads((R/prev['path']).read_text()));iq=d['inquiry']
 external=json.loads((R/'evidence/R008-build-all71-feedback-v1.json').read_text());seen={x['attempt_id'] for x in external}
 for a in s['attempts']:
  if a['attempt_id'] not in seen:external.append({'attempt_id':a['attempt_id'],'task_id':a['task_id'],'receipt_ref':a['receipt_ref'],'valid_execution':a['result']=='succeeded','feedback_kind':'inquiry'})
  if not any(o.get('attempt_id')==a['attempt_id'] for o in iq['observations']):
   obs={'id':'obs-'+a['attempt_id'],'attempt_id':a['attempt_id'],'task_id':a['task_id'],'receipt_ref':a['receipt_ref'],'outcome':'supports' if a['result']=='succeeded' else 'invalid','affected_layer':'implementation' if a['result']=='succeeded' else 'infrastructure','affected_explanation_ids':[],'interpretation':'Actual prior task receipt read; '+reason+' Runtime/build outcome alone is not native witness/algorithm success.'};iq['observations'].append(obs);iq['based_on_observation_ids'].append(obs['id'])
 feedback=write('evidence/'+tid+'-all-feedback.json',external)
 d.update(decision_id='W5-'+tid+'-selection-v1',previous_ref=prev,selected_task_ids=[tid],evidence_change='boundary',why_selected=reason)
 iq['next_check'].update(question=t['purpose'],task_ids=[tid],input_refs=t['input_refs']+[feedback]);
 if next_actions is not None:iq['next_check']['outcome_actions']=next_actions
 d['evidence_refs'] +=[feedback]+[x for x in t['input_refs'] if x not in d['evidence_refs']][:8]
 dr=write('plans/'+tid+'-decision-v4.json',d);t.update(reasoning_ref=dr,input_refs=t['input_refs']+[feedback,dr]);write('plans/'+tid+'-task.json',t)
 report=reasoning.check_task(R,t,candidate_id='constraint-propagation-cost-v1');write('evidence/'+tid+'-reasoning-preflight.json',report);assert not report['gaps'],report['gaps'];reasoning.require_host_feedback(R,t,external)
 fresh={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'kernel_only_memory_policy':True,'cpu_count':os.cpu_count()}
 for f in ['cpu.max','memory.max','memory.current','memory.stat','memory.events']:
  p=pathlib.Path('/sys/fs/cgroup')/f
  if p.exists():fresh[f]=p.read_text()
 write('evidence/'+tid+'-host-observation.json',fresh)
 req=next(x['snapshot'] for x in s['requests'] if x['state']=='open');resp={'response_id':'respond-'+tid,'request_id':req['request_id'],'idea':s['journal']['active_idea'],'revision':req['revision'],'goal_contract_version':req['goal_contract_version'],'reason':reason,'events':[{'event_id':'review-'+tid,'kind':'research_review','decision_ref':dr,'evidence':[dr],'reason':reason}],'tasks':[t]}
 write('plans/'+tid+'-response.json',resp);result=r.respond(resp);raw=json.dumps(result).encode();p=R/'evidence'/('respond-'+tid+'.json.zst');p.write_bytes(zstandard.ZstdCompressor().compress(raw));write('evidence/'+tid+'-response-identity.json',{'raw_bytes':len(raw),'raw_sha256':hashlib.sha256(raw).hexdigest(),'zstd_sha256':hashlib.sha256(p.read_bytes()).hexdigest()});print(json.dumps({'accepted':tid,'feedback_receipts':len(external),'previous_ref':prev}))
if __name__=='__main__':advance(sys.argv[1],sys.argv[2])
