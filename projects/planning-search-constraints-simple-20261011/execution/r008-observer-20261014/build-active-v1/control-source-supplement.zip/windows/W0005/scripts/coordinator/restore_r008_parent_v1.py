import json,zipfile,hashlib
from pathlib import Path
from restore_subset import SplitReader,digest
B=Path(__file__).resolve().parent;R=B/'project/windows/W0005';m=json.loads((B/'core68-manifest.json').read_text())
assert digest(B/'core68-manifest.json')=='af0708304697337f7c36b1cac238167fa2522bee75a4aad5df12b909484b328f'
prefix='windows/W0004/vendor/scorpion_cpu_clock_coarse_r006_v1/'
items=[x for x in m['files'] if x['path'].startswith(prefix) ]
groups={}
for x in items:groups.setdefault(x['pack'],[]).append(x)
rows=[]
for pack, entries in groups.items():
 reader=SplitReader(pack)
 with zipfile.ZipFile(reader) as z:
  for x in entries:
   target=R/'vendor/scorpion_r008_observer_v1'/x['path'][len(prefix):];target.parent.mkdir(parents=True,exist_ok=True)
   if not target.exists():
    with z.open(x['member']) as src,target.open('xb') as out:
     while data:=src.read(1048576):out.write(data)
   assert target.stat().st_size==x['bytes'] and digest(target)==x['sha256']
   rows.append({**x,'restored_path':str(target.relative_to(R))})
 print(json.dumps({'pack':pack,'members':len(entries),'touched_parts':sorted(reader.verified)}),flush=True)
out=R/'evidence/R008-full-observer-parent-source-restoration-v1.json';out.write_text(json.dumps({'core_manifest_sha256':digest(B/'core68-manifest.json'),'scope':'Selected source members and touched compressed part hashes, not full archive reread','files':rows},indent=2)+'\n')
print('restored',len(rows))
